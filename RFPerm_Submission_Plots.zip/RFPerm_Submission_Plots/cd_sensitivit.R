power_df <- read.csv("power_perm_samplesizeratio_covariateshift_bi_adjustment.csv")
colors <- c(
"power oob" = "red",
"power oob bidir" = "blue",
"power xgb" = "purple",
"power xgb bidir" = "orange",
"power lgb" = "green",
"power lgb bidir" = "black"
  )
png("power_perm_samplesizeratio_covariateshift_bidirectional.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_oob, group = 1, color = "power oob"), linewidth = 1.25) + 
  geom_line(aes(y = power_oob_bi, group = 1, color = "power oob bidir"), linewidth = 1.25) + 
  geom_line(aes(y = power_xgb, group = 1, color = "power xgb"), linewidth = 1.25) + 
  geom_line(aes(y = power_xgb_bi, group = 1, color = "power xgb bidir"), linewidth = 1.25) + 
  geom_line(aes(y = power_lgb, group = 1, color = "power lgb"), linewidth = 1.25) + 
  geom_line(aes(y = power_lgb_bi, group = 1, color = "power lgb bidir"), linewidth = 1.25) + 
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying sample size ratio \n Covariate Shift: Both Mean Shift and Variance Shift") +   
scale_color_manual(values = colors) + 
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 32)) + 
theme(axis.title = element_text(size = 32)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 32), 
legend.text = element_text(size = 32)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()