#RFPerm plots:
df <- data.frame(
snr = c(0.05, 0.09, 0.14, 0.25, 0.42, 0.71, 1.22, 2.07, 3.52, 6),
power0 = numeric(10),
power1 = numeric(10),
power2 = numeric(10),
power3 = numeric(10),
power4 = numeric(10),
power5 = numeric(10),
power6 = numeric(10),
power7 = numeric(10)
)
for(i in 1:8){
  t_df <- read.csv(paste("data_files/", i, "_typeIerror_permOOB_LM.csv", sep = ""))
  df[, i + 1] <- t_df$power
}
#Figure 1: Type-I error for cor = 0 ~ 0.3
png('permoob_typeIerror_LM1.png', width = 900, height = 950)
df$snr <- as.factor(df$snr)
colors <- c("cor = 0.0" = "blue",
"cor = 0.1" = "purple",
"cor = 0.2" = "red",
"cor = 0.3" = "brown")
ggplot(df, aes(x = snr)) + 
  geom_line(aes(y = power0, color = "cor = 0.0", group = 1), linewidth = 2) + 
  geom_line(aes(y = power1, color = "cor = 0.1", group = 1), linewidth = 2) + 
  geom_line(aes(y = power2, color = "cor = 0.2", group = 1), linewidth = 2) + 
  geom_line(aes(y = power3, color = "cor = 0.3", group = 1), linewidth = 2) + 
  scale_color_manual(values = colors) +  labs(x = "SNR",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  scale_y_continuous(limits = c(0, 0.2)) +     
  ggtitle("RFPerm Type-I error Comparison Linear Model: Cor = 0 ~ 0.3") +   
    scale_color_manual(values = colors) + 
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) + 
    guides(colour = guide_legend(nrow = 1, byrow = TRUE)) +                      
     theme(plot.title = element_text(size = 28)) + 
   theme(axis.text = element_text(size = 25)) + 
   theme(axis.title = element_text(size = 25)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 30), 
        legend.text = element_text(size = 30)) + 
    theme(legend.title = element_blank())     
dev.off()

png('permoob_typeIerror_LM2.png', width = 900, height = 950)
df$snr <- as.factor(df$snr)
colors <- c("cor = 0.4" = "blue",
"cor = 0.5" = "purple",
"cor = 0.6" = "red",
"cor = 0.7" = "brown")
ggplot(df, aes(x = snr)) + 
  geom_line(aes(y = power4, color = "cor = 0.4", group = 1), linewidth = 1) + 
  geom_line(aes(y = power5, color = "cor = 0.5", group = 1), linewidth = 1) + 
  geom_line(aes(y = power6, color = "cor = 0.6", group = 1), linewidth = 1) + 
  geom_line(aes(y = power7, color = "cor = 0.7", group = 1), linewidth = 1) + 
  scale_color_manual(values = colors) + 
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +                      
   labs(x = "SNR",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  scale_y_continuous(limits = c(0, 0.2)) +       
  ggtitle("RFPerm Type-I error Comparison Linear Model: Cor = 0.4 ~ 0.7") + 
    scale_color_manual(values = colors) + 
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          panel.background = element_blank(), axis.line = element_line(colour = "black")) + 
     theme(plot.title = element_text(size = 28)) + 
   theme(axis.text = element_text(size = 25)) + 
   theme(axis.title = element_text(size = 25)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 30), 
        legend.text = element_text(size = 30)) + 
    theme(legend.title = element_blank())     
dev.off()

#Type-I error for Mars Normal Model:
df1 <- data.frame(
n_nuisance = c(5, 10, 20, 30, 50, 75, 100, 150, 200, 300),
power1 = numeric(10), power2 = numeric(10), power3 = numeric(10),
power4 = numeric(10), power5 = numeric(10), power6 = numeric(10),
power7 = numeric(10), power8 = numeric(10), power9 = numeric(10),
power10 = numeric(10), power11 = numeric(10), power12 = numeric(10),
power13 = numeric(10)
)
df2 <- df1
for(i in 1:13){
  power_df <- read.csv(paste("data_files/", i, " sigmaseq_typeIerror_mars1_permutationtestOOB.csv", sep = ""))
  df1[, i + 1] <- power_df$typeIerror
}
sigma_seq <- c(0.1, 0.2, 0.5, 0.75, 1, 1.5, 2, 3, 5, 10, 20, 50, 100)
#Figure 3: Type-I error for Mars Model Normal: Good Data Quality:
png('permoob_typeIerror_Mars1_LowNoise.png', width = 900, height = 950)
df1$n_nuisance <- as.factor(df1$n_nuisance)
colors <- c("sigma = 0.1" = "blue",
"sigma = 0.5" = "purple",
"sigma = 0.75" = "red",
"sigma = 1" = "brown",
"sigma = 1.5" = "green")
ggplot(df1, aes(x = n_nuisance)) + 
  geom_line(aes(y = power1, color = "sigma = 0.1", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power3, color = "sigma = 0.5", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power4, color = "sigma = 0.75", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power5, color = "sigma = 1", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power6, color = "sigma = 1.5", group = 1), linewidth = 1.5) +   
  scale_color_manual(values = colors) +  labs(x = "Number of Nuisance Features",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  ggtitle("RFPerm Type-I error Comparison Mars Model Normal: \n Good Data Quality") +
  scale_y_continuous(limits = c(0, 0.2)) +            
    scale_color_manual(values = colors) + 
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          panel.background = element_blank(), axis.line = element_line(colour = "black")) +     
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +                      
     theme(plot.title = element_text(size = 28)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 28), 
        legend.text = element_text(size = 28)) + 
    theme(legend.title = element_blank()) +    
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()
png('permoob_typeIerror_Mars1_HighNoise.png', width = 900, height = 950)
df1$n_nuisance <- as.factor(df1$n_nuisance)
colors <- c("sigma = 3" = "blue",
"sigma = 5" = "purple",
"sigma = 20" = "red",
"sigma = 50" = "brown",
"sigma = 100" = "green")
ggplot(df1, aes(x = n_nuisance)) + 
  geom_line(aes(y = power8, color = "sigma = 3", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power9, color = "sigma = 5", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power10, color = "sigma = 10", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power11, color = "sigma = 20", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power12, color = "sigma = 50", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power13, color = "sigma = 100", group = 1), linewidth = 1.5) +   
  scale_color_manual(values = colors) +  labs(x = "Number of Nuisance Features",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  ggtitle("PermOOB Type-I error Comparison Mars Model Normal: \n Bad Data Quality") + 
  scale_y_continuous(limits = c(0, 0.2)) +            
  scale_color_manual(values = colors) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + 
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +                  
  theme(plot.title = element_text(size = 28)) + 
  theme(axis.text = element_text(size = 28)) + 
  theme(axis.title = element_text(size = 28)) + 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 28), 
        legend.text = element_text(size = 28)) + 
  theme(legend.title = element_blank()) +     
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

for(i in 1:13){
  power_df <- read.csv(paste("data_files/", i, " sigmaseq_typeIerror_mars2_permutationtestOOB.csv", sep = ""))
  df2[, i + 1] <- power_df$typeIerror
}
sigma_seq <- c(0.1, 0.2, 0.5, 0.75, 1, 1.5, 2, 3, 5, 10, 20, 50, 100)
#Figure 5: Type-I error for Mars Model Uniform: Good Data Quality:
png('permoob_typeIerror_Mars2_LowNoise.png', width = 900, height = 950)
df2$n_nuisance <- as.factor(df2$n_nuisance)
colors <- c("sigma = 0.1" = "blue",
"sigma = 0.5" = "purple",
"sigma = 0.75" = "red",
"sigma = 1" = "brown",
"sigma = 1.5" = "green")
ggplot(df2, aes(x = n_nuisance)) + 
  geom_line(aes(y = power1, color = "sigma = 0.1", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power3, color = "sigma = 0.5", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power4, color = "sigma = 0.75", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power5, color = "sigma = 1", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power6, color = "sigma = 1.5", group = 1), linewidth = 1.5) +   
  scale_color_manual(values = colors) +  labs(x = "Number of Nuisance Features",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  ggtitle("PermOOB Type-I error Comparison Mars Model Uniform: \n Good Data Quality") + 
  scale_y_continuous(limits = c(0, 0.2)) +              
    scale_color_manual(values = colors) + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +     
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +                  
  theme(plot.title = element_text(size = 28)) + 
  theme(axis.text = element_text(size = 28)) + 
  theme(axis.title = element_text(size = 28)) + 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 28), 
        legend.text = element_text(size = 28)) + 
  theme(legend.title = element_blank()) +     
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()
#Figure 6: Type-I error for Mars Model Uniform: Bad Data Quality:
png('permoob_typeIerror_Mars2_HighNoise.png', width = 900, height = 950)
df2$n_nuisance <- as.factor(df2$n_nuisance)
colors <- c("sigma = 3" = "blue",
"sigma = 5" = "purple",
"sigma = 20" = "red",
"sigma = 50" = "brown",
"sigma = 100" = "green")
ggplot(df2, aes(x = n_nuisance)) + 
  geom_line(aes(y = power8, color = "sigma = 3", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power10, color = "sigma = 5", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power11, color = "sigma = 20", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power12, color = "sigma = 50", group = 1), linewidth = 1.5) + 
  geom_line(aes(y = power13, color = "sigma = 100", group = 1), linewidth = 1.5) +   
  scale_color_manual(values = colors) +  labs(x = "Number of Nuisance Features",
       y = "Type-I error",
       color = "Legend") + theme_bw() +
  ggtitle("PermOOB Type-I error Comparison Mars Model Uniform:\n Bad Data Quality") + 
  scale_y_continuous(limits = c(0, 0.2)) +                
    scale_color_manual(values = colors) + 
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + 
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +                  
  theme(plot.title = element_text(size = 28)) + 
  theme(axis.text = element_text(size = 28)) + 
  theme(axis.title = element_text(size = 28)) + 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 28), 
        legend.text = element_text(size = 28)) + 
  theme(legend.title = element_blank()) +     
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


#"cd_benchmark_corr01_conceptdrift1_rfperm.png"
power_df <- read.csv("data_files/power_df_cdonly_benchmark_conceptdrift1_cor01.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformalnn" = "skyblue1",
 "power_conformallr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr01_conceptdrift1_rfperm.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Power Comparison \n Concept Drift Model 1, Corr = 0.1")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 26), 
legend.text = element_text(size = 26)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cdonly_benchmark_conceptdrift1_cor05.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_autotst" = "red",
 "power_conformalnn" = "skyblue1",
 "power_conformallr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
  )
png("cd_benchmark_corr05_conceptdrift1_rfperm.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +              
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Power Comparison \n Concept Drift Model 1, Corr = 0.5")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 26), 
legend.text = element_text(size = 26)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cdonly_benchmark_cor01_conceptdrift2.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformalnn" = "skyblue1",
 "power_conformallr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr01_conceptdrift2_rfperm.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformallr"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +                  
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Power Comparison - \n Concept Drift Model 2, Corr = 0.1")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 26), 
legend.text = element_text(size = 26)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cdonly_benchmark_cor05.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformalnn" = "skyblue1",
 "power_conformallr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr05_conceptdrift2_rfperm.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.25) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.25) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.25) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.25) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.25) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.25) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.25) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.25) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.25) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.25) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.25) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.25) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.25) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformallr"), linewidth = 1.25) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.25) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.25) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.25) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Power Comparison \n Concept Drift Model 2, Corr = 0.5")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 26), 
legend.text = element_text(size = 26)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/dataquality_benchmark_SNR1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformal_nn" = "skyblue1",
 "power_conformal_lr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red3",
    "power_lgb" = "green2"
  )
png("dataquality_benchmark_1.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(dif_snr))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.5) +    
  geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.5) +             
  labs(x = "Difference of SNR", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Power Comparison - Data Quality Change \n Mars Model, Starting From SNR = 0.4 ")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/dataquality_benchmark_SNR2.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_cf" = "skyblue4",
  "power_autotst" = "red",
  "power_conformal_nn" = "skyblue1",
  "power_conformal_lr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red3",
    "power_lgb" = "green2"
  )
png("dataquality_benchmark_2.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(dif_snr))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.5) +     
  geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.5) +             
  labs(x = "Difference of SNR", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Comparison - Data Quality Change \n Mars Model, Starting SNR = 0.67 ")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

power_df <- read.csv("data_files/power_df_covariateshiftonly1_nuisance.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_cf" = "sienna3",
  "power_autotst" = "sienna1",
  "power_conformalnn" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red",
    "power_lgb" = "green3"
  )
png("power_df_CSCD_bothXY_covariateshift_nuisance_rfperm.png", width = 900, height = 950)
power_df$n_nuisance <- as.factor(power_df$n_nuisance)
ggplot(power_df, aes(x = n_nuisance)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_autotst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +       
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste(" Covariate Shift with Nuisance Features \n Benchmark Power Comparison")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_corrincrease_benchmark.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformal_nn" = "skyblue1",
 "power_conformal_lr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red3",
    "power_lgb" = "green2"
  )
png("corr_increasebenchmark_RFPerm.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(dif_cor))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Difference of Correlation", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Comparison - Correlation Change \n Linear Model, Starting rho = 0.2 ")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/power_df_benchmark_covariateshiftonly2.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
 # "power_cf" = "skyblue4",
  "power_autotst" = "red",
  "power_conformal_nn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
  )
png("power_benchmark_covariateshiftonly2_cdonly.png", width = 900, height = 950)
power_df$shift <- as.factor(power_df$shift)
ggplot(power_df, aes(x = shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformal_nn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Power Comparison for Existing Methods \n Covariate Shift: Mean Shift on top of Minor Variance Shift")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_benchmark_covariateshiftonly4.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
 # "power_cf" = "skyblue4",
  "power_autotst" = "red",
  "power_conformal_nn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "sienna",
    "power_lgb" = "green4"
  )
png("power_benchmark_covariateshiftonly4_cdonly.png", width = 900, height = 950)
power_df$shift <- as.factor(power_df$shift)
ggplot(power_df, aes(x = shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformal_nn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.5) +     
  geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.5) +             
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Existing Methods \n Covariate Shift: Variance Shift on top of Mean Shift")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

power_df <- read.csv("data_files/power_df_CSCD_bothXY.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_cf" = "sienna3",
  "power_autotst" = "red",
    "power_conformalnn" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red3",
    "power_lgb" = "blue3"
  )
png("power_df_CSCD_bothXY_meanshift_rfperm.png", width = 900, height = 950)
power_df$mean_shift <- as.factor(power_df$mean_shift)
ggplot(power_df, aes(x = mean_shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +   
  geom_line(aes(y = power_autotst, group = 1, color = "power_autotst"), linewidth = 1.5) +   
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +       
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +  
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +         
  labs(x = "Mean Shift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste(" Mean Shift on top of Concept Drift \n Benchmark Comparison")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/power_df_CSCD_bothXY_varianceshift.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_cf" = "sienna3",
  "power_autotst" = "red",
    "power_conformalnn" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red4",
    "power_lgb" = "red3"
  )
png("power_df_CSCD_bothXY_varianceshift_rfperm.png", width = 900, height = 950)
power_df$variance_shift <- as.factor(power_df$variance_shift)
ggplot(power_df, aes(x = variance_shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +   
  geom_line(aes(y = power_autotst, group = 1, color = "power_autotst"), linewidth = 1.5) +   
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +  
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +     
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +  
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +       
  labs(x = "Variance Shift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste(" Variance Shift on top of Concept Drift \n Benchmark Comparison")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 29), 
legend.text = element_text(size = 29)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cd_ontopof_cs_benchmark.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
  "power_conformalnn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("power_df_cd_ontopof_cs_benchmark.png", width = 900, height = 950)
power_df$cd_sequence <- as.factor(power_df$cd_sequence)
ggplot(power_df, aes(x = cd_sequence)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.5) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.5) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.5) +             
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Power Comparison \n Concept Drift on top of Covariate Shift \nBoth Mean Shift and Variance Shift")) +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 29), 
legend.text = element_text(size = 29)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

library(dplyr)
library(ggplot2)
library(tidyr)

#Type-I error for LM Model:
power_df <- read.csv("data_files/permOOBC_typeIerror_LM.csv")
png("PermOOBC_typeIerror_LM.png", width = 900, height = 950)
colors <- c("Type-I error cor = 0.0" = "blue","Type-I error cor = 0.2" = "red",
"Type-I error cor = 0.4" = "brown","Type-I error cor = 0.6" = "purple")
power_df$pn_ratio <- c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4)
ggplot(power_df, aes(x = as.factor(pn_ratio))) + 
geom_line(aes(y = cor00, color = "Type-I error cor = 0.0", group = 1), linewidth = 1.5) + 
geom_line(aes(y = cor02, color = "Type-I error cor = 0.2", group = 1), linewidth = 1.5) + 
geom_line(aes(y = cor04, color = "Type-I error cor = 0.4", group = 1), linewidth = 1.5) + 
geom_line(aes(y = cor06, color = "Type-I error cor = 0.6", group = 1), linewidth = 1.5) + 
  scale_color_manual(values = colors) +  labs(x = "p/n",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  scale_y_continuous(limits = c(0, 0.3)) + theme_bw() + 
  ggtitle("RFPerm-C Type-I error Comparison Linear Model, \n n = 500, 8 signal features") +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 30)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 29), 
legend.text = element_text(size = 29)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

#Type-I error for Mars Model:
power_df <- read.csv("data_files/permOOBC_typeIerror_Mars.csv")
colors <- c("5 nuisance features" = "red",
"25 nuisance features" = "blue", 
"45 nuisance features" = "green",
"95 nuisance features" = "purple",
"195 nuisance features" = "brown",
"495 nuisance features" = "cyan3",
"995 nuisance features" = "yellow",
"1995 nuisance features" = "pink")
png("PermOOBC_typeIerror_Mars.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = nuis5, color = "5 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis25, color = "25 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis45, color = "45 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis95, color = "95 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis195, color = "195 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis495, color = "495 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis995, color = "995 nuisance features", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nuis1995, color = "1995 nuisance features", group = 1), linewidth = 1.5) + 
scale_color_manual(values = colors) +  labs(x = "Noise Level",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
scale_y_continuous(limits = c(0, 0.3)) +     
ggtitle("RFPerm-C Type-I error Comparison Mars Model \n n = 500, 5 signal features") +   
scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 4, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 29), 
legend.text = element_text(size = 29)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/permOOBC_typeIerror_longsignal_LM.csv")
colors <- c("Type-I error cor = 0.0" = "red",
  "Type-I error cor = 0.2" = "blue",
  "Type-I error cor = 0.4" = "brown",
  "Type-I error cor = 0.6" = "green")
png("permOOBC_typeIerror_longsignal_LM.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = t_cor00, group = 1, color = "Type-I error cor = 0.0"), linewidth = 1.5) + 
  geom_line(aes(y = t_cor02, group = 1, color = "Type-I error cor = 0.2"), linewidth = 1.5) + 
  geom_line(aes(y = t_cor04, group = 1, color = "Type-I error cor = 0.4"), linewidth = 1.5) + 
  geom_line(aes(y = t_cor06, group = 1, color = "Type-I error cor = 0.6"), linewidth = 1.5) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + theme_bw() + 
   ggtitle("Type-I error for RFPerm-C \n 100 Signal features, n = 500, p = 200") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 0.3)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 26)) + 
theme(axis.title = element_text(size = 26)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 29), 
legend.text = element_text(size = 29)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cd_benchmark_cor01_conceptdrift1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformalnn" = "skyblue1",
 "power_conformallr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr01_conceptdrift1_rfperm_classification.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformallr"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Comparison Binary Classification \n Concept Drift Model 1, Corr = 0.1")) +   
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 7, byrow = TRUE)) +         
theme(axis.text = element_text(size = 25)) + 
theme(axis.title = element_text(size = 25)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cd_benchmark_cor05_conceptdrift1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformalnn" = "skyblue1",
 "power_conformallr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr05_conceptdrift2_rfperm_classification_.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.5) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformallr"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Comparison Binary Classification \n Concept Drift Model 2, Corr = 0.5")) +   
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 7, byrow = TRUE)) +         
theme(axis.text = element_text(size = 25)) + 
theme(axis.title = element_text(size = 25)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

power_df <- read.csv("data_files/power_df_cs_ontop_cd_classifier_2.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_autotst" = "red",
 # "power_conformalnn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
  )
png("power_df_cs_ontopof_cd1_classifier_rfperm.png", width = 900, height = 950)
power_df$mean_shift <- as.factor(power_df$mean_shift_seq)
ggplot(power_df, aes(x = mean_shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  #geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.25) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Mean Shift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Existing Methods \n Mean Shift on top of Concept Drift")) +   
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 5, byrow = TRUE)) +         
theme(axis.text = element_text(size = 25)) + 
theme(axis.title = element_text(size = 25)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cs_ontop_cd_classifier_1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  "power_cf" = "skyblue4",
  "power_autotst" = "red",
 # "power_conformalnn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
    #"power_xgb" = "red3",
    #"power_lgb" = "green2"
  )
power_df$variance_shift <- seq(1, 2.3, 0.1)
png("power_df_cs_ontopof_cd2_classifier_rfperm.png", width = 900, height = 950)
power_df$variance_shift <- as.factor(power_df$variance_shift)
ggplot(power_df, aes(x = variance_shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  #geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.25) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Variance Shift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Existing Methods \n Variance Shift on top of Concept Drift")) +   
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 5, byrow = TRUE)) +         
theme(axis.text = element_text(size = 25)) + 
theme(axis.title = element_text(size = 25)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cscd_nuisance_classifier.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
 # "power_cf" = "skyblue4",
  "power_autotst" = "red",
 # "power_conformalnn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4",
    "power_xgb" = "red3",
    "power_lgb" = "green2"
  )
png("power_df_cscd_nuisance_classifier_rfperm.png", width = 900, height = 950)
power_df$n_nuisance <- as.factor(power_df$n_nuisance)
ggplot(power_df, aes(x = n_nuisance)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  #geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.25) +  
  #geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.25) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Existing Methods \n Covariate Shift + Concept Drift \n Binary Classification - Nuisance Features")) +   
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 5, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/permOOBC_power_dataqualitydrop1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
 # "power_cf" = "skyblue4",
  "power_autotst" = "red",
  "power_conformalnn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
  )
png("permOOBC_power_dataqualitydrop1.png", width = 900, height = 950)
power_df$dif_eps <- as.factor(power_df$dif_eps)
ggplot(power_df, aes(x = dif_eps)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.5) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.5) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.5) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.5) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.5) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.5) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.5) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.5) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.5) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.5) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.5) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.5) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.5) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.5) +             
  labs(x = "Epsilon Difference", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Existing Methods \n Data Quality Drop - Binary Response")) +   
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 28)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


#Power for the mean shift ontopof concept drift:
power_df <- data.frame(
  mean_shift = seq(0, 1.5, 0.05),
  power_sigma10 = numeric(31),
  power_sigma15 = numeric(31),
  power_sigma20 = numeric(31)
)
power_df$power_sigma10 <- read.csv("data_files/permOOBC_meanshiftontopofconceptdrift_cor0.3_sigma10.csv")$power
power_df$power_sigma15 <- read.csv("data_files/permOOBC_meanshiftontopofconceptdrift_cor0.3_sigma15.csv")$power
power_df$power_sigma20 <- read.csv("data_files/permOOBC_meanshiftontopofconceptdrift_cor0.3_sigma20.csv")$power
png("permOOBC_meanshiftontopofconceptdrift.png",
  width = 900, height = 950)
colors <- c("sigma = 10" = "red",
           "sigma = 15" = "blue",
           "sigma = 20" = "brown")
ggplot(power_df, aes(x = as.factor(mean_shift))) + 
  geom_line(aes(y = power_sigma10, group = 1, color = "sigma = 10"), linewidth = 1.5) + 
  geom_line(aes(y = power_sigma15, group = 1, color = "sigma = 15"), linewidth = 1.5) + 
  geom_line(aes(y = power_sigma20, group = 1, color = "sigma = 20"), linewidth = 1.5) + 
  labs(x = "Degree of Mean Shift", y = "Power", color = "Legend") + 
  ggtitle("ower Robustness for RFPerm-C \n Mean Shift on top of Concept Drift") +   
  guides(colour = guide_legend(nrow = 1, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 1, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- data.frame(
  mean_shift = seq(1, 3, 0.1),
  power_sigma10 = numeric(21),
  power_sigma15 = numeric(21),
  power_sigma20 = numeric(21)
  )
power_df$power_sigma10 <- read.csv("data_files/permOOBC_varianceshiftontopofconceptdrift_cor0.3_sigma10.csv")$power
power_df$power_sigma15 <- read.csv("data_files/permOOBC_varianceshiftontopofconceptdrift_cor0.3_sigma15.csv")$power
power_df$power_sigma20 <- read.csv("data_files/permOOBC_varianceshiftontopofconceptdrift_cor0.3_sigma20.csv")$power
png("permOOBC_varianceshiftontopofconceptdrift.png",
  width = 900, height = 950)
colors <- c("sigma = 10" = "red",
           "sigma = 15" = "blue",
           "sigma = 20" = "brown")
ggplot(power_df, aes(x = as.factor(mean_shift))) + 
  geom_line(aes(y = power_sigma10, group = 1, color = "sigma = 10"), linewidth = 1.5) + 
  geom_line(aes(y = power_sigma15, group = 1, color = "sigma = 15"), linewidth = 1.5) + 
  geom_line(aes(y = power_sigma20, group = 1, color = "sigma = 20"), linewidth = 1.5) + 
  labs(x = "Degree of Variance Shift", y = "Power", color = "Legend") + 
   ggtitle("Power Robustness for RFPerm-C \n Variance Shift on top of Concept Drift") +   
guides(colour = guide_legend(nrow = 1, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 1, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- read.csv("data_files/permOOBC_typeIerror_tuning.csv")
png("permOOBC_tuning_typeIerror_Mars.png", width = 900, height = 950)
colors <- c("non_tuning" = "red",
  "mtry_tuning" = "blue",
  "minnode_tuning" = "brown",
  "mtry_minnode_tuning" = "green")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = typeIerror0, group = 1, color = "non_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror1, group = 1, color = "mtry_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror2, group = 1, color = "minnode_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror3, group = 1, color = "mtry_minnode_tuning"), linewidth = 1.5) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + 
   ggtitle("Type-I error for RFPerm-C - Tuning Comparison, n = 500, p = 20") +   
scale_color_manual(values = colors) +  
scale_y_continuous(limits = c(0, 0.2)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- read.csv("data_files/permOOBC_typeIerror_tuning2.csv")
png("permOOBC_tuning_typeIerror_Mars2.png", width = 900, height = 950)
colors <- c("non_tuning" = "red",
  "mtry_tuning" = "blue",
  "minnode_tuning" = "brown",
  "mtry_minnode_tuning" = "green")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = typeIerror0, group = 1, color = "non_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror1, group = 1, color = "mtry_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror2, group = 1, color = "minnode_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror3, group = 1, color = "mtry_minnode_tuning"), linewidth = 1.5) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + 
   ggtitle("Type-I error for RFPerm-C - Tuning Comparison, n = 500, p = 100") +   
scale_color_manual(values = colors) + 
scale_y_continuous(limits = c(0, 0.2)) +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- read.csv("data_files/permOOBC_typeIerror_tuning3.csv")
png("permOOBC_tuning_typeIerror_Mars3.png", width = 900, height = 950)
colors <- c("non_tuning" = "red",
  "mtry_tuning" = "blue",
  "minnode_tuning" = "brown",
  "mtry_minnode_tuning" = "green")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = typeIerror0, group = 1, color = "non_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror1, group = 1, color = "mtry_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror2, group = 1, color = "minnode_tuning"), linewidth = 1.5) + 
  geom_line(aes(y = typeIerror3, group = 1, color = "mtry_minnode_tuning"), linewidth = 1.5) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + theme_bw() + 
   ggtitle("Type-I error for RFPerm-C - Tuning Comparison, n = 500, p = 1000") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 0.2)) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()




df <- read.csv("data_files/permOOBC_conceptdrift1_sigma3_n_nuisance.csv")
df$pn_ratio <- c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4, 6, 10)
colors <- c(
  "power cor = 0.0" = "blue",
  "power cor = 0.2" = "red",
  "power cor = 0.4" = "brown",
  "power cor = 0.6" = "green"
  )
png("permOOBC_conceptdrift1_sigma3_nnuisance.png", width = 900, height = 950)
ggplot(df, aes(x = as.factor(pn_ratio))) + 
  geom_line(aes(y = sigma3_cor00, group = 1, color = "power cor = 0.0"), linewidth = 1.5) + 
  geom_line(aes(y = sigma3_cor02, group = 1, color = "power cor = 0.2"), linewidth = 1.5) + 
  geom_line(aes(y = sigma3_cor04, group = 1, color = "power cor = 0.4"), linewidth = 1.5) + 
  geom_line(aes(y = sigma3_cor06, group = 1, color = "power cor = 0.6"), linewidth = 1.5) + 
  labs(x = "p/n", y = "Power", color = "Legend") + theme_bw() + 
  ggtitle("Power for RFPerm-C Concept Drift Model 1 \n Nuisance Features, sigma = 3") +   
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
  scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

df <- read.csv("data_files/permOOBC_conceptdrift1_sigma10_n_nuisance.csv")
df$pn_ratio <- c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4, 6, 10)
colors <- c(
  "power cor = 0.0" = "blue",
  "power cor = 0.2" = "red",
  "power cor = 0.4" = "brown",
  "power cor = 0.6" = "green"
  )
png("permOOBC_conceptdrift1_sigma10_nnuisance.png", width = 900, height = 950)
ggplot(df, aes(x = as.factor(pn_ratio))) + 
  geom_line(aes(y = sigma10_cor00, group = 1, color = "power cor = 0.0"), linewidth = 1.5) + 
  geom_line(aes(y = sigma10_cor02, group = 1, color = "power cor = 0.2"), linewidth = 1.5) + 
  geom_line(aes(y = sigma10_cor04, group = 1, color = "power cor = 0.4"), linewidth = 1.5) + 
  geom_line(aes(y = sigma10_cor06, group = 1, color = "power cor = 0.6"), linewidth = 1.5) + 
  labs(x = "p/n", y = "Power", color = "Legend") + 
   ggtitle("Power for RFPerm-C Concept Drift Model 1 \n Nuisance Features, sigma = 10") +   
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
  scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 25), 
legend.text = element_text(size = 25)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()




eps_seq <- c(0.1, 0.2, 0.5, 1, 2, 3, 5, 7.5, 10, 15, 20, 30, 50, 100)
df <- data.frame(
  eps = eps_seq,
  power_m0 = numeric(14),
  power_m1 = numeric(14),
  power_m2 = numeric(14),
  power_m3 = numeric(14),
  power_m4 = numeric(14),
  power_m5 = numeric(14),
  power_m6 = numeric(14)
  )
df$power_m0 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0_nuisance_feature_count_15.csv")$power
df$power_m1 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.1_nuisance_feature_count_15.csv")$power
df$power_m2 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.2_nuisance_feature_count_15.csv")$power
df$power_m3 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.3_nuisance_feature_count_15.csv")$power
df$power_m4 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.4_nuisance_feature_count_15.csv")$power
df$power_m5 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.5_nuisance_feature_count_15.csv")$power
df$power_m6 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.6_nuisance_feature_count_15.csv")$power
write.csv(df, "permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count15.csv")
df <- read.csv("permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count15.csv")
png("permOOBC_missingratio_15nuisancefeature.png", width = 900, height = 950)
colors <- c("missingratio 0.0" = "red",
            "missingratio 0.1" = "blue",
            "missingratio 0.2" = "brown",
            "missingratio 0.3" = "green",
            "missingratio 0.4" = "cyan3",
            "missingratio 0.5" = "black",
            "missingratio 0.6" = "purple")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = power_m0, group = 1, color = "missingratio 0.0"), linewidth = 1.5) + 
  geom_line(aes(y = power_m1, group = 1, color = "missingratio 0.1"), linewidth = 1.5) + 
  geom_line(aes(y = power_m2, group = 1, color = "missingratio 0.2"), linewidth = 1.5) + 
  geom_line(aes(y = power_m3, group = 1, color = "missingratio 0.3"), linewidth = 1.5) + 
  geom_line(aes(y = power_m4, group = 1, color = "missingratio 0.4"), linewidth = 1.5) + 
  geom_line(aes(y = power_m5, group = 1, color = "missingratio 0.5"), linewidth = 1.5) +   
  geom_line(aes(y = power_m6, group = 1, color = "missingratio 0.6"), linewidth = 1.5) +     
  labs(x = "Noise Level", y = "Power", color = "Legend") + 
   ggtitle("Power for RFPerm-C Missing Value in \n New Batch of Data - n = 500, p = 20") +   
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- read.csv("data_files/permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count95.csv")
png("permOOBC_missingratio_95nuisancefeature.png", width = 900, height = 950)
colors <- c("missingratio 0.0" = "red",
            "missingratio 0.1" = "blue",
            "missingratio 0.15" = "brown",
            "missingratio 0.25" = "green",
            "missingratio 0.35" = "cyan3",
            "missingratio 0.45" = "black",
            "missingratio 0.5" = "purple")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = power_m0, group = 1, color = "missingratio 0.0"), linewidth = 1.5) + 
  geom_line(aes(y = power_m1, group = 1, color = "missingratio 0.1"), linewidth = 1.5) + 
  geom_line(aes(y = power_m15, group = 1, color = "missingratio 0.15"), linewidth = 1.5) + 
  geom_line(aes(y = power_m25, group = 1, color = "missingratio 0.25"), linewidth = 1.5) + 
  geom_line(aes(y = power_m35, group = 1, color = "missingratio 0.35"), linewidth = 1.5) + 
  geom_line(aes(y = power_m45, group = 1, color = "missingratio 0.45"), linewidth = 1.5) +   
  geom_line(aes(y = power_m5, group = 1, color = "missingratio 0.5"), linewidth = 1.5) +     
  labs(x = "Noise Level", y = "Power", color = "Legend") + 
  ggtitle("Power for PermOOBC Missing Value in \n New Batch of Data - n = 500, p = 100") +   
  guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + 
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- read.csv("data_files/permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count1495.csv")
png("permOOBC_missingratio_1495nuisancefeature.png", width = 900, height = 950)
colors <- c("missingratio 0.0" = "red",
            "missingratio 0.1" = "blue",
            "missingratio 0.15" = "brown",
            "missingratio 0.25" = "green",
            "missingratio 0.35" = "cyan3",
            "missingratio 0.45" = "black",
            "missingratio 0.5" = "purple")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = power_m0, group = 1, color = "missingratio 0.0"), linewidth = 1.5) + 
  geom_line(aes(y = power_m1, group = 1, color = "missingratio 0.1"), linewidth = 1.5) + 
  geom_line(aes(y = power_m15, group = 1, color = "missingratio 0.15"), linewidth = 1.5) + 
  geom_line(aes(y = power_m25, group = 1, color = "missingratio 0.25"), linewidth = 1.5) + 
  geom_line(aes(y = power_m35, group = 1, color = "missingratio 0.35"), linewidth = 1.5) + 
  geom_line(aes(y = power_m45, group = 1, color = "missingratio 0.45"), linewidth = 1.5) +   
  geom_line(aes(y = power_m5, group = 1, color = "missingratio 0.5"), linewidth = 1.5) +     
  labs(x = "Noise Level", y = "Power", color = "Legend") + 
   ggtitle("Power for PermOOBC Missing Value in \n New Batch of Data - n = 500, p = 1500") +   
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()




df <- data.frame(
  pn_ratio = c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4),
  powereps0.1 = numeric(13),
  powereps1 = numeric(13),
  powereps2 = numeric(13),
  powereps5 = numeric(13),
  powereps10 = numeric(13),
  powereps20 = numeric(13)
  )
nuis_seq <- c(5, 15, 25, 35, 45, 95, 145, 195, 295, 495, 995, 1495, 1995)
for(i in 1:13){
  pdf <- read.csv(paste("data_files/permOOBC_conceptdrift1_power_nuisancefeature", 
    nuis_seq[i], "nuisance_eps_2.csv", sep = "_"))
  df$powereps0.1[i] <- pdf$power[1]
  df$powereps1[i] <- pdf$power[4]
  df$powereps2[i] <- pdf$power[5]
  df$powereps5[i] <- pdf$power[7]
  df$powereps10[i] <- pdf$power[9]
  df$powereps20[i] <- pdf$power[11]
}

png("permOOBC_ttail_nuisance_eps2.png", width = 900, height = 950)
colors <- c("power eps = 0.1" = "red",
            "power eps = 1" = "blue",
            "power eps = 2" = "brown",
            "power eps = 5" = "green",
            "power eps = 10" = "cyan3",
            "power eps = 20" = "black")
ggplot(df, aes(x = as.factor(pn_ratio))) + 
  geom_line(aes(y = powereps0.1, group = 1, color = "power eps = 0.1"), linewidth = 2) + 
  geom_line(aes(y = powereps1, group = 1, color = "power eps = 1"), linewidth = 2) + 
  geom_line(aes(y = powereps2, group = 1, color = "power eps = 2"), linewidth = 2) + 
  geom_line(aes(y = powereps5, group = 1, color = "power eps = 5"), linewidth = 2) + 
  geom_line(aes(y = powereps10, group = 1, color = "power eps = 10"), linewidth = 2) + 
  geom_line(aes(y = powereps20, group = 1, color = "power eps = 20"), linewidth = 2) +   
  labs(x = "p/n", y = "Power", color = "Legend") + 
  ggtitle("Power for RFPerm-C T-Distribution Noise df = 2") +   
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



df <- data.frame(
  pn_ratio = c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4),
  powereps0.1 = numeric(13),
  powereps1 = numeric(13),
  powereps2 = numeric(13),
  powereps5 = numeric(13),
  powereps10 = numeric(13),
  powereps20 = numeric(13)
  )
nuis_seq <- c(5, 15, 25, 35, 45, 95, 145, 195, 295, 495, 995, 1495, 1995)
for(i in 1:13){
  pdf <- read.csv(paste("data_files/permOOBC_conceptdrift1_power_nuisancefeature", 
    nuis_seq[i], "nuisance_eps_3.csv", sep = "_"))
  df$powereps0.1[i] <- pdf$power[1]
  df$powereps1[i] <- pdf$power[4]
  df$powereps2[i] <- pdf$power[5]
  df$powereps5[i] <- pdf$power[7]
  df$powereps10[i] <- pdf$power[9]
  df$powereps20[i] <- pdf$power[11]
}
df <- read.csv("data_files/permOOBC_ttail_sigma3.csv")
png("permOOBC_ttail_nuisance_eps3.png", width = 900, height = 950)
colors <- c("power eps = 0.1" = "red",
            "power eps = 1" = "blue",
            "power eps = 2" = "brown",
            "power eps = 5" = "green",
            "power eps = 10" = "cyan3",
            "power eps = 20" = "black")
ggplot(df, aes(x = as.factor(pn_ratio))) + 
  geom_line(aes(y = powereps0.1, group = 1, color = "power eps = 0.1"), linewidth = 2) + 
  geom_line(aes(y = powereps1, group = 1, color = "power eps = 1"), linewidth = 2) + 
  geom_line(aes(y = powereps2, group = 1, color = "power eps = 2"), linewidth = 2) + 
  geom_line(aes(y = powereps5, group = 1, color = "power eps = 5"), linewidth = 2) + 
  geom_line(aes(y = powereps10, group = 1, color = "power eps = 10"), linewidth = 2) + 
  geom_line(aes(y = powereps20, group = 1, color = "power eps = 20"), linewidth = 2) +   
  labs(x = "p/n", y = "Power", color = "Legend") + theme_bw() + 
  ggtitle("Power for PermOOBC T-Distribution Noise df = 3") +   
  guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + 
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 28)) + 
theme(axis.title = element_text(size = 28)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()




t1_df <- read.csv("data_files/typeIerror_eta_subsamplepower.csv")
png("typeIerror_eta_subsamplepower.png", width = 900, height = 950)
colors <- c("sigma = 1" = "red",
            "sigma = 15" = "blue")
t1_df$eta <- as.factor(t1_df$eta)
ggplot(t1_df, aes(x = eta)) + 
  geom_line(aes(y = typeIerror_mean1, group = 1, color = "sigma = 1"), linewidth = 2) + 
  #geom_errorbar(aes(ymin = typeIerror_mean1 - typeIerror_sd1,
  #                  ymax = typeIerror_mean1 + typeIerror_sd1, color = "sigma = 1", width = 0.2), size = 1) + 
  geom_line(aes(y = typeIerror_mean2, group = 1, color = "sigma = 15"), linewidth = 2) + 
  #geom_errorbar(aes(ymin = typeIerror_mean2 - typeIerror_sd2,
  #                  ymax = typeIerror_mean2 + typeIerror_sd2, color = "sigma = 15", width = 0.2), size = 1) + 
  labs(x = "Subsampling Ratio - eta", y = "Type-I Error", color = "Legend") + 
    scale_color_manual(values = colors) + theme_bw() + 
   ggtitle("RFPerm: Sensitivity Analysis for type-I error \n with different subsampling ratio") +       
  guides(colour = guide_legend(nrow = 1, byrow = TRUE)) + 
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 0.15)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



df_eta <- read.csv("data_files/eta_covariateshift_power_sensitivityanalysis.csv")
png("power_sensitivity_Mars.png", width = 900, height = 950)
colors <- c("Mars1-eps1" = "red", "Mars1-eps8" = "blue",
            "Mars2-eps8" = "green")
df_eta$eta <- as.factor(df_eta$eta)
ggplot(df_eta, aes(x = eta)) +
  geom_line(aes(y = power_mean1, group = 1, color = "Mars1-eps1"), linewidth = 2) +
  geom_line(aes(y = power_mean2, group = 1, color = "Mars1-eps8"), linewidth = 2) +
  geom_line(aes(y = power_mean3, group = 1, color = "Mars2-eps8"), linewidth = 2) +  
  labs(x = "Subsampling Ratio - eta", y = "power", color = "Legend") + 
   ggtitle("RFPerm: Sensitivity Analysis for power \n with different subsampling rate: Mars") +      
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



df_eta <- read.csv("data_files/power_eta_subsample_sigma20.csv")
png("permoob_power_eta_subsample_sigma20_Mars.png", width = 900, height = 950)
colors <- c("sigma = 20" = "red")
df_eta$eta <- as.factor(df_eta$eta_subsampling)
ggplot(df_eta, aes(x = eta)) + 
geom_line(aes(y = power_mean, group = 1, color = "sigma = 20"), linewidth = 2) +
geom_errorbar(aes(ymin = power_mean - power_sd,
  ymax = power_mean + power_sd, color = "sigma = 20"), width = 0.2, size = 1.5) + 
labs(x = "eta_subsample", y = "Power", color = "Legend") + 
ggtitle("PermOOB: Sensitivity Analysis for Power \n with different subsampling rate: Mars, sigma = 20") + 
    theme(legend.title = element_blank()) +
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/nratio_typeIerror_permOOB.csv")
png('nratio_typeIerror_bidirection_permOOB.png', width = 900, height = 950)
colors <- c("Concept Drift1 - Direction1" = "red",
  "Concept Drift1 - Direction2" = "blue",
  "Concept Drift2 - Direction1" = "orange",
  "Concept Drift2 - Direction2" = "green",
  "Mars Model - Direction1" = "purple",
  "Mars Model - Direction2" = "brown")
ggplot(power_df, aes(x = as.factor(n_ratio))) + 
  geom_line(aes(y = typeIerror_CD1_1, group = 1, color = "Concept Drift1 - Direction1"), linewidth = 2) + 
  geom_line(aes(y = typeIerror_CD1_2, group = 1, color = "Concept Drift1 - Direction2"), linewidth = 2) + 
  geom_line(aes(y = typeIerror_CD2_1, group = 1, color = "Concept Drift2 - Direction1"), linewidth = 2) + 
  geom_line(aes(y = typeIerror_CD2_2, group = 1, color = "Concept Drift2 - Direction2"), linewidth = 2) + 
  geom_line(aes(y = typeIerror_Mars1, group = 1, color = "Mars Model - Direction1"), linewidth = 2) + 
  geom_line(aes(y = typeIerror_Mars2, group = 1, color = "Mars Model - Direction2"), linewidth = 2) + 
  labs(x = "n_exist/n_new", y = "Type-I error", color = "Legend") + 
ggtitle("Type-I error PermOOB Bidirection \n Varying sample-ratio n_exist/n_new") +                                                     
    theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 0.25)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/1_SNRdrop_LM_permOOB_new_bi_direc.csv")
power_df2 <- read.csv("data_files/2_SNRdrop_LM_permOOB_new_bi_direc.csv")
power_df3 <- read.csv("data_files/3_SNRdrop_LM_permOOB_new_bi_direc.csv")
power_df$SNR1_1 <- power_df$power_dir1
power_df$SNR1_2 <- power_df$power_dir2
power_df$SNR2_1 <- power_df2$power_dir1
power_df$SNR2_2 <- power_df2$power_dir2
power_df$SNR3_1 <- power_df3$power_dir1
power_df$SNR3_2 <- power_df3$power_dir2
colors <- c("SNR = 1 Data Quality Increase BiDirectional" = "red",
            "SNR = 1 Data Quality Increase One-Direction" = "blue",
            "SNR = 2 Data Quality Increase BiDirectional" = "orange",
            "SNR = 2 Data Quality Increase One-Direction" = "green",
            "SNR = 3 Data Quality Increase BiDirectional" = "brown",
            "SNR = 3 Data Quality Increase One-Direction" = "black")
png('dataquality_drop_Bidirection.png', width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(dif_snr))) + 
  geom_line(aes(y = SNR1_1, group = 1, color = "SNR = 1 Data Quality Increase Bi-Directional"), linewidth = 2) + 
  geom_line(aes(y = SNR1_2, group = 1, color = "SNR = 1 Data Quality Increase One-Direction"), linewidth = 2) + 
  geom_line(aes(y = SNR2_1, group = 1, color = "SNR = 2 Data Quality Increase Bi-Directional"), linewidth = 2) + 
  geom_line(aes(y = SNR2_2, group = 1, color = "SNR = 2 Data Quality Increase One-Direction"), linewidth = 2) + 
  geom_line(aes(y = SNR3_1, group = 1, color = "SNR = 3 Data Quality Increase Bi-Directional"), linewidth = 2) + 
  geom_line(aes(y = SNR3_2, group = 1, color = "SNR = 3 Data Quality Increase One-Direction"), linewidth = 2) +   
  labs(x = "SNR Difference", y = "Power", color = "Legend") + 
ggtitle("Power PermOOB Data Quality Difference Linear Model \n One-Directional vs. Bidirectional Procedure") +                                                     
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/bidirec_covariateshiftonly.csv")
colors <- c(
  "bidirection C.S. only1" = "red",
  "onedirection C.S. only1" = "blue",
  "bidirection C.S. only3" = "orange",
  "onedirection C.S. only3" = "green",
  "bidirection C.S. only4" = "brown",
  "onedirection C.S. only4" = "black"  
  )
png('bidirec_covariateshiftonly.png', width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(dif_sigma_seq))) + 
  geom_line(aes(y = bi_cs1, group = 1, color = "bidirection C.S. only1"), linewidth = 2) + 
  geom_line(aes(y = one_cs1, group = 1, color = "onedirection C.S. only1"), linewidth = 2) + 
  geom_line(aes(y = bi_cs3, group = 1, color = "bidirection C.S. only3"), linewidth = 2) + 
  geom_line(aes(y = one_cs3, group = 1, color = "onedirection C.S. only3"), linewidth = 2) + 
  geom_line(aes(y = bi_cs4, group = 1, color = "bidirection C.S. only4"), linewidth = 2) + 
  geom_line(aes(y = one_cs4, group = 1, color = "onedirection C.S. only4"), linewidth = 2) +   
  labs(x = "Sigma Difference", y = "Power", color = "Legend") + 
ggtitle("Power for RFPerm with Covariate Shift Only \n One-Directional vs. Bidirectional Procedure") +                                                     
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 28), 
legend.text = element_text(size = 28)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()




power_df <- read.csv("data_files/power_df_cdonly_benchmark_bidir_gbdt.csv")
colors <- c(
  "power_oob_lancaster" = "blue",
  "power_oob" = "red",
  "power_xgb_lancaster" = "brown",
  "power_xgb" = "green",
  "power_lgb_lancaster" = "orange",
  "power_lgb" = "black"
  )
png("power_df_cdonly_benchmark_bidirection_xgblgboob.png", width = 900, height = 950)
power_df$eps <- as.factor(power_df$eps_seq)
ggplot(power_df, aes(x = eps)) +
  geom_line(aes(y = power_oob_lancaster, group = 1, color = "power_oob_lancaster"), linewidth = 1.5) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.5) + 
  geom_line(aes(y = power_xgb_lancaster, group = 1, color = "power_xgb_lancaster"), linewidth = 1.5) + 
  geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.5) + 
  geom_line(aes(y = power_lgb_lancaster, group = 1, color = "power_lgb_lancaster"), linewidth = 1.5) + 
  geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.5) +            
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Bidirectional Procedure \nConcept Drift only - Concept Drift Model 1")) +   
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cdonly_benchmark_bidir_gbdt.csv")
colors <- c(
  "power_oob_lancaster" = "blue",
  "power_oob" = "red",
  "power_xgb_lancaster" = "brown",
  "power_xgb" = "green",
  "power_lgb_lancaster" = "orange",
  "power_lgb" = "black"
  )
png("power_df_cdonly_benchmark_bidirection_xgblgboob.png", width = 900, height = 950)
power_df$eps <- as.factor(power_df$eps_seq)
ggplot(power_df, aes(x = eps)) +
  geom_line(aes(y = power_oob_lancaster, group = 1, color = "power_oob_lancaster"), linewidth = 2) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 2) + 
  geom_line(aes(y = power_xgb_lancaster, group = 1, color = "power_xgb_lancaster"), linewidth = 2) + 
  geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 2) + 
  geom_line(aes(y = power_lgb_lancaster, group = 1, color = "power_lgb_lancaster"), linewidth = 2) + 
  geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 2) +            
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + 
ggtitle(paste("Benchmark Comparison for Bidirectional Procedure \nConcept Drift only - Concept Drift Model 1")) +   
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()




df <- read.csv("data_files/permOOBC_typeIerror_tuning.csv")
png("permOOBC_tuning_typeIerror_Mars.png", width = 900, height = 950)
colors <- c("non_tuning" = "red",
  "mtry_tuning" = "blue",
  "minnode_tuning" = "brown",
  "mtry_minnode_tuning" = "green")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = typeIerror0, group = 1, color = "non_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror1, group = 1, color = "mtry_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror2, group = 1, color = "minnode_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror3, group = 1, color = "mtry_minnode_tuning"), linewidth = 2) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + 
   ggtitle("Type-I error for PermOOBC - Tuning Comparison, n = 500, p = 20") +   
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 0.2)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

df <- read.csv("data_files/permOOBC_typeIerror_tuning2.csv")
png("permOOBC_tuning_typeIerror_Mars2.png", width = 900, height = 950)
colors <- c("non_tuning" = "red",
  "mtry_tuning" = "blue",
  "minnode_tuning" = "brown",
  "mtry_minnode_tuning" = "green")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = typeIerror0, group = 1, color = "non_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror1, group = 1, color = "mtry_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror2, group = 1, color = "minnode_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror3, group = 1, color = "mtry_minnode_tuning"), linewidth = 2) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + 
   ggtitle("Type-I error for PermOOBC - Tuning Comparison, n = 500, p = 100") +   
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 0.2)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

df <- read.csv("data_files/permOOBC_typeIerror_tuning3.csv")
png("permOOBC_tuning_typeIerror_Mars3.png", width = 900, height = 950)
colors <- c("non_tuning" = "red",
  "mtry_tuning" = "blue",
  "minnode_tuning" = "brown",
  "mtry_minnode_tuning" = "green")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = typeIerror0, group = 1, color = "non_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror1, group = 1, color = "mtry_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror2, group = 1, color = "minnode_tuning"), linewidth = 2) + 
  geom_line(aes(y = typeIerror3, group = 1, color = "mtry_minnode_tuning"), linewidth = 2) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + theme_bw() + 
   ggtitle("Type-I error for PermOOBC - Tuning Comparison, n = 500, p = 1000") +   
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 0.2)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()

power_df <- data.frame(
  eps = eps_seq,
  power2 = numeric(14),
  power5 = numeric(14),
  power10 = numeric(14),
  power15 = numeric(14),
  power30 = numeric(14),
  power50 = numeric(14)
  )
power_df$power2 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_50_comparison.csv")$power
power_df$power5 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_5_nuisancefeature_50_comparison.csv")$power
power_df$power10 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_10_nuisancefeature_50_comparison.csv")$power
power_df$power15 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_15_nuisancefeature_50_comparison.csv")$power
power_df$power30 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_30_nuisancefeature_50_comparison.csv")$power
power_df$power50 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_50_nuisancefeature_50_comparison.csv")$power
colors <- c(
  "var = 2" = "red",
  "var = 5" = "brown",
  "var = 10" = "purple",
  "var = 15" = "green",
  "var = 30" = "blue", 
  "var = 50" = "black")
png("PermOOB_power_ttail2_nuisance50.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power2, color = "var = 2", group = 1), linewidth = 1) + 
geom_line(aes(y = power5, color = "var = 5", group = 1), linewidth = 1) + 
geom_line(aes(y = power10, color = "var = 10", group = 1),linewidth = 1) + 
geom_line(aes(y = power15, color = "var = 15", group = 1),linewidth = 1) + 
geom_line(aes(y = power30, color = "var = 30", group = 1),linewidth = 1) + 
 geom_line(aes(y = power50, color = "var = 50", group = 1),linewidth = 1) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("PermOOB: Concept Drift 2 T-distribution Varying Noise, n = 500, p = 50") + 
    scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 27)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- data.frame(
  eps = eps_seq
  )
power_df$nu10 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_10_comparison.csv")$power
power_df$nu25 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_25_comparison.csv")$power
power_df$nu50 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_50_comparison.csv")$power
power_df$nu100 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_100_comparison.csv")$power
power_df$nu125 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_125_comparison.csv")$power
power_df$nu150 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_150_comparison.csv")$power
power_df$nu75 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_75_comparison.csv")$power
colors <- c(
  "10 nuisance" = "blue",
  "25 nuisance" = "green",
  "50 nuisance" = "red",
  "150 nuisance" = "black",
  "100 nuisance" = "purple",
  "125 nuisance" = "cyan3",
  "75 nuisance" = "brown")
png("PermOOB_ttail2_2nuisancevariance.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = nu10, color = "10 nuisance", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nu25, color = "25 nuisance", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nu50, color = "50 nuisance", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nu75, color = "75 nuisance", group = 1), linewidth = 1.5) + 
geom_line(aes(y = nu100, color = "100 nuisance", group = 1),linewidth = 1.5) + 
geom_line(aes(y = nu125, color = "125 nuisance", group = 1),linewidth = 1.5) + 
geom_line(aes(y = nu150, color = "150 nuisance", group = 1),linewidth = 1.5) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() +
  ggtitle("PermOOB: Concept Drift Model 2 T-distribution Variance = 2, n = 500") + 
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
theme(plot.title = element_text(size = 32)) + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
theme(axis.text = element_text(size = 30)) + 
theme(axis.title = element_text(size = 30)) + 
theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
theme(legend.position='bottom') +
theme(legend.title = element_text(size = 30), 
legend.text = element_text(size = 30)) + 
theme(legend.title = element_blank()) + 
theme(legend.key.size = unit(1, 'cm')) 
dev.off()



#Visualization for all the plots:
#sudo yum install python3-pip -y
#python3 -m pip install numpy pandas scipy 


df_power_1 <- data.frame(
  sample_size_seq = c(10, 20, 30, 50, 100, 200, 250, 300, 500),
  sample1_power = numeric(9),
  sample2_power = numeric(9),
  sample3_power = numeric(9),
  sample4_power = numeric(9)
)
for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelA", i, "nuisance.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelAnuis_null_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1.5) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1.5) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1.5) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1.5) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features \n Model A null, sigma = 1") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
theme(legend.title = element_blank()) + theme_bw() + 
scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelB", i, "nuisance_baddata.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1_baddata.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1.5) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1.5) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"), linewidth = 1.5) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"), linewidth = 1.5) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
  ggtitle("Power for number of nuisance features \n Model B null, sigma = 5") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelB", i, "nuisance_baddata2.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1_baddata2.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1.75) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1.75) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"), linewidth = 1.75) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"), linewidth = 1.75) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
  ggtitle("Power for number of nuisance features \n Model B null, sigma = 10") +   
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelB", i, "nuisance_baddata3.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1_baddata3.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1.75) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1.75) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"), linewidth = 1.75) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"), linewidth = 1.75) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features \n Model B null, sigma = 20") +   
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df_power_1 <- data.frame(
  sample_size_seq = c(10, 20, 30, 50, 100, 200, 250, 300, 500),
  sample1_power = numeric(9),
  sample2_power = numeric(9),
  sample3_power = numeric(9),
  sample4_power = numeric(9)
)
for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelB", i, "nuisance.csv", sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model B null, sigma = 1") +   
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelA", i, "nuisance.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelAnuis_null_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features \n Model A null, sigma = 1") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelB", i, "nuisance_baddata2.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1_baddata2.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"), linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"), linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
  ggtitle("Power for number of nuisance features - Model B null, sigma = 10") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()





for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelB", i, "nuisance_baddata3.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1_baddata3.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"), linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"), linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model B null, sigma = 20") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) + theme_bw() +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelB", i, "nuisance.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelBnuis_null_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1.75) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1.75) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1.75) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1.75) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
  ggtitle("Power for number of nuisance features - Model B null, sigma = 1") +   
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
  scale_color_manual(values = colors) + theme_bw() +
  scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelA", i, "nuisance.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_null[1]
  df_power_1$sample2_power[i] <- power_df$power_null[2]
  df_power_1$sample3_power[i] <- power_df$power_null[3]
  df_power_1$sample4_power[i] <- power_df$power_null[4]
}
png("power_modelAnuis_null_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
  ggtitle("Power for number of nuisance features - Model A null, sigma = 1") +   
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
  scale_color_manual(values = colors) + theme_bw() +
  scale_y_continuous(limits = c(0, 1)) +
     theme(plot.title = element_text(size = 27)) + 
   theme(axis.text = element_text(size = 24)) + 
   theme(axis.title = element_text(size = 24)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 26), 
        legend.text = element_text(size = 26)) + 
  theme(legend.key.size = unit(1, 'cm')) + 
  theme(legend.title=element_blank()) + 
  scale_color_manual(values = colors)
dev.off()


df_power_1 <- data.frame(
  sample_size_seq = c(10, 20, 30, 50, 100, 200, 250, 300, 500),
  sample1_power = numeric(9),
  sample2_power = numeric(9),
  sample3_power = numeric(9),
  sample4_power = numeric(9)
)
for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelA", i, "nuisance_baddata.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
####
#drawing the trend of the power curve here:
png("power_modelAnuis_alt_1_baddata.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + theme_bw() + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model A alt, sigma = 5") + 
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelA", i, "nuisance_baddata2.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
####
#drawing the trend of the power curve here:
png("power_modelAnuis_alt_1_baddata2.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") +
   ggtitle("Power for number of nuisance features - Model A alt, sigma = 10") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelA", i, "nuisance_baddata3.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
####
#drawing the trend of the power curve here:
png("power_modelAnuis_alt_1_baddata3.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"),linewidth=1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"),linewidth=1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth=1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth=1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model A alt, sigma = 20") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


########
for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelB", i, "nuisance_baddata.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
png("power_modelBnuis_alt_1_baddata.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model B alt, sigma = 5") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelB", i, "nuisance_baddata2.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
png("power_modelBnuis_alt_1_baddata2.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model B alt, sigma = 10") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + theme_bw() + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) +
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelB", i, "nuisance_baddata3.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
png("power_modelBnuis_alt_1_baddata3.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"),linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"),linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model B alt, sigma = 20") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("power_df_modelB", i, "nuisance.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
png("power_modelBnuis_alt_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features - Model B alt, sigma = 1") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


for(i in 1:9){
  power_df <- read.csv(paste("data_files/power_df_modelA", i, "nuisance.csv",
                             sep = "_"))
  df_power_1$sample1_power[i] <- power_df$power_alt[1]
  df_power_1$sample2_power[i] <- power_df$power_alt[2]
  df_power_1$sample3_power[i] <- power_df$power_alt[3]
  df_power_1$sample4_power[i] <- power_df$power_alt[4]
}
png("power_modelAnuis_alt_1.png", width = 900, height = 950)
colors <- c("sample_size200" = "red",
            "sample_size500" = "blue",
            "sample_size1000" = "orange",
            "sample_size2000" = "brown")
df_power_1$nuisance_feature <- as.factor(df_power_1$sample_size_seq)
ggplot(df_power_1, aes(x = nuisance_feature)) + 
  geom_line(aes(y = sample1_power, group = 1, color = "sample_size200"), linewidth = 1.75) + 
  geom_line(aes(y = sample2_power, group = 1, color = "sample_size500"), linewidth = 1.75) + 
  geom_line(aes(y = sample3_power, group = 1, color = "sample_size1000"),linewidth = 1.75) + 
  geom_line(aes(y = sample4_power, group = 1, color = "sample_size2000"),linewidth = 1.75) + 
  labs(x = "Number of Nuisance Features", y = "Power", color = "Legend") + 
   ggtitle("Power for number of nuisance features \n Model A alternative, sigma = 1") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) + theme_bw() +                
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
scale_color_manual(values = colors) + 
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 8)/500
result_df <- data.frame(
  pn_ratio = pn_ratio,
  typeIerror1 = numeric(17),
  power1 = numeric(17),
  typeIerror2 = numeric(17),
  power2 = numeric(17),
  typeIerror3 = numeric(17),
  power3 = numeric(17),
  typeIerror4 = numeric(17),
  power4 = numeric(17)
  )
t1_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
t2_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
t3_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
t4_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
power_df1 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
power_df2 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
power_df3 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
power_df4 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
result_df$typeIerror1 <- t1_df$power
result_df$typeIerror2 <- t2_df$power
result_df$power1 <- power_df1$power 
result_df$power2 <- power_df2$power
result_df$typeIerror3 <- t3_df$power
result_df$typeIerror4 <- t4_df$power
result_df$power3 <- power_df3$power 
result_df$power4 <- power_df4$power

png("permoob_highdim_pn_power1.png", width = 900, height = 950)
colors <- c("power cor0.0" = "red", "power cor0.2" = "blue",
  "power cor0.4" = "orange", "power cor0.6" = "brown")
ggplot(result_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
  geom_line(aes(y = power1, color = "power cor0.0", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power2, color = "power cor0.2", group = 1), linewidth = 1.75) +
  geom_line(aes(y = power3, color = "power cor0.4", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power4, color = "power cor0.6", group = 1), linewidth = 1.75) +  
  scale_color_manual(values = colors) +  
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +   
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + theme_bw() + 
  ggtitle("Power for Concept Drift Model \n High-Dimensional Comparison, n = 500") + 
  scale_y_continuous(limits = c(0, 1)) + 
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()




power_df <- data.frame(
  eps = eps_seq
  )
power_df$nu10 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_10_comparison.csv")$power
power_df$nu25 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_25_comparison.csv")$power
power_df$nu50 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_50_comparison.csv")$power
power_df$nu100 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_100_comparison.csv")$power
power_df$nu125 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_125_comparison.csv")$power
power_df$nu150 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_150_comparison.csv")$power
power_df$nu75 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_75_comparison.csv")$power
colors <- c(
  "10 nuisance" = "blue",
  "25 nuisance" = "green",
  "50 nuisance" = "red",
  "150 nuisance" = "black",
  "100 nuisance" = "purple",
  "125 nuisance" = "cyan3",
  "75 nuisance" = "brown")
png("PermOOB_ttail2_2nuisancevariance.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = nu10, color = "10 nuisance", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nu25, color = "25 nuisance", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nu50, color = "50 nuisance", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nu75, color = "75 nuisance", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nu100, color = "100 nuisance", group = 1),linewidth = 1.75) + 
geom_line(aes(y = nu125, color = "125 nuisance", group = 1),linewidth = 1.75) + 
geom_line(aes(y = nu150, color = "150 nuisance", group = 1),linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() +
  ggtitle("RFPerm: Concept Drift Model 2 \n T-distribution Variance = 2, n = 500") + 
  scale_y_continuous(limits = c(0, 1)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()




nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 8)/500
result_df <- data.frame(
  pn_ratio = pn_ratio,
  typeIerror1 = numeric(17),
  power1 = numeric(17),
  typeIerror2 = numeric(17),
  power2 = numeric(17),
  typeIerror3 = numeric(17),
  power3 = numeric(17),
  typeIerror4 = numeric(17),
  power4 = numeric(17)
  )
t1_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
t2_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
t3_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
t4_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
power_df1 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
power_df2 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
power_df3 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
power_df4 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
result_df$typeIerror1 <- t1_df$power
result_df$typeIerror2 <- t2_df$power
result_df$power1 <- power_df1$power 
result_df$power2 <- power_df2$power
result_df$typeIerror3 <- t3_df$power
result_df$typeIerror4 <- t4_df$power
result_df$power3 <- power_df3$power 
result_df$power4 <- power_df4$power

png("permoob_highdim_pn_power1.png", width = 900, height = 950)
colors <- c("power cor0.0" = "red", "power cor0.2" = "blue",
  "power cor0.4" = "orange", "power cor0.6" = "brown")
ggplot(result_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
  geom_line(aes(y = power1, color = "power cor0.0", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power2, color = "power cor0.2", group = 1), linewidth = 1.75) +
  geom_line(aes(y = power3, color = "power cor0.4", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power4, color = "power cor0.6", group = 1), linewidth = 1.75) +  
  scale_color_manual(values = colors) +  
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +   
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + theme_bw() + 
  ggtitle("Power for Concept Drift \n High-Dimensional Comparison, n = 500") + 
  scale_y_continuous(limits = c(0, 1)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/power_df_cdonly_benchmark_bidir_gbdt.csv")
colors <- c(
  "power_oob_lancaster" = "blue",
  "power_oob" = "red",
  "power_xgb_lancaster" = "brown",
  "power_xgb" = "green",
  "power_lgb_lancaster" = "orange",
  "power_lgb" = "black"
  )
png("power_df_cdonly_benchmark_bidirection_xgblgboob.png", width = 900, height = 950)
power_df$eps <- as.factor(power_df$eps_seq)
ggplot(power_df, aes(x = eps)) +
  geom_line(aes(y = power_oob_lancaster, group = 1, color = "power_oob_lancaster"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.75) + 
  geom_line(aes(y = power_xgb_lancaster, group = 1, color = "power_xgb_lancaster"), linewidth = 1.75) + 
  geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.75) + 
  geom_line(aes(y = power_lgb_lancaster, group = 1, color = "power_lgb_lancaster"), linewidth = 1.75) + 
  geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.75) +            
  labs(x = "Degree of Concept Drift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Bidirectional Procedure \n Concept Drift only - Concept Drift Model 1")) +   
  scale_y_continuous(limits = c(0, 1)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

df <- data.frame(
  eps = eps_seq,
  power_m0 = numeric(14),
  power_m1 = numeric(14),
  power_m2 = numeric(14),
  power_m3 = numeric(14),
  power_m4 = numeric(14),
  power_m5 = numeric(14),
  power_m6 = numeric(14)
  )
df$power_m0 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0_nuisance_feature_count_15.csv")$power
df$power_m1 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.1_nuisance_feature_count_15.csv")$power
df$power_m2 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.2_nuisance_feature_count_15.csv")$power
df$power_m3 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.3_nuisance_feature_count_15.csv")$power
df$power_m4 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.4_nuisance_feature_count_15.csv")$power
df$power_m5 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.5_nuisance_feature_count_15.csv")$power
df$power_m6 <- read.csv("data_files/permOOBC_conceptdrift1_power_missingratio_0.6_nuisance_feature_count_15.csv")$power
write.csv(df, "permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count15.csv")
df <- read.csv("permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count15.csv")
png("permOOBC_missingratio_15nuisancefeature.png", width = 900, height = 950)
colors <- c("missingratio 0.0" = "red",
            "missingratio 0.1" = "blue",
            "missingratio 0.2" = "brown",
            "missingratio 0.3" = "green",
            "missingratio 0.4" = "cyan3",
            "missingratio 0.5" = "black",
            "missingratio 0.6" = "purple")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = power_m0, group = 1, color = "missingratio 0.0"), linewidth = 1.75) + 
  geom_line(aes(y = power_m1, group = 1, color = "missingratio 0.1"), linewidth = 1.75) + 
  geom_line(aes(y = power_m2, group = 1, color = "missingratio 0.2"), linewidth = 1.75) + 
  geom_line(aes(y = power_m3, group = 1, color = "missingratio 0.3"), linewidth = 1.75) + 
  geom_line(aes(y = power_m4, group = 1, color = "missingratio 0.4"), linewidth = 1.75) + 
  geom_line(aes(y = power_m5, group = 1, color = "missingratio 0.5"), linewidth = 1.75) +   
  geom_line(aes(y = power_m6, group = 1, color = "missingratio 0.6"), linewidth = 1.75) +     
  labs(x = "Noise Level", y = "Power", color = "Legend") + 
   ggtitle("Power for RFPerm-C Missing Value \n in New Batch of Data - n = 500, p = 20") +   
  scale_y_continuous(limits = c(0, 1)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



df <- read.csv("data_files/permoobc_conceptdrift1_power_missingratio_varying_nuisance_feature_count95.csv")
png("permOOBC_missingratio_95nuisancefeature.png", width = 900, height = 950)
colors <- c("missingratio 0.0" = "red",
            "missingratio 0.1" = "blue",
            "missingratio 0.15" = "brown",
            "missingratio 0.25" = "green",
            "missingratio 0.35" = "cyan3",
            "missingratio 0.45" = "black",
            "missingratio 0.5" = "purple")
ggplot(df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = power_m0, group = 1, color = "missingratio 0.0"), linewidth = 1.75) + 
  geom_line(aes(y = power_m1, group = 1, color = "missingratio 0.1"), linewidth = 1.75) + 
  geom_line(aes(y = power_m15, group = 1, color = "missingratio 0.15"), linewidth = 1.75) + 
  geom_line(aes(y = power_m25, group = 1, color = "missingratio 0.25"), linewidth = 1.75) + 
  geom_line(aes(y = power_m35, group = 1, color = "missingratio 0.35"), linewidth = 1.75) + 
  geom_line(aes(y = power_m45, group = 1, color = "missingratio 0.45"), linewidth = 1.75) +   
  geom_line(aes(y = power_m5, group = 1, color = "missingratio 0.5"), linewidth = 1.75) +     
  labs(x = "Noise Level", y = "Power", color = "Legend") + 
   ggtitle("Power for RFPerm-C Missing Value in \n New Batch of Data - n = 500, p = 100") +   
  scale_y_continuous(limits = c(0, 1)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- data.frame(
  eps = eps_seq,
  power_10 = numeric(14),
  power_25 = numeric(14),
  power_50 = numeric(14),
  power_75 = numeric(14),
  power_100 = numeric(14),
  power_150 = numeric(14),
  power_200 = numeric(14)
  )
power_df$power_10 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_10_comparison.csv")$power
power_df$power_25 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_25_comparison.csv")$power
power_df$power_50 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_50_comparison.csv")$power
power_df$power_75 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_75_comparison.csv")$power
power_df$power_100 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_100_comparison.csv")$power
power_df$power_150 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_150_comparison.csv")$power
power_df$power_200 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_200_comparison.csv")$power

power_df$eps <- as.factor(power_df$eps)
colors <- c(
  "10 nuisance features" = "red",
  "25 nuisance features" = "brown",
  "50 nuisance features" = "purple",
  "75 nuisance features" = "green",
  "100 nuisance features" = "blue", 
  "150 nuisance features" = "orange",
  "200 nuisance features" = "black")
png("PermOOB_typeIerror_ttail2_nuisance1.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power_10, color = "10 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_25, color = "25 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_50, color = "50 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_75, color = "75 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_100, color = "100 nuisance features", group = 1), linewidth = 1.75) + 
 geom_line(aes(y = power_150, color = "150 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_200, color = "200 nuisance features", group = 1), linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Type-I error",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("RFPerm: Type-I error T-distribution Noise, \n under Varying Noise Level") + 
  scale_y_continuous(limits = c(0, 1)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- data.frame(
  eps = eps_seq,
  power_10 = numeric(14),
  power_25 = numeric(14),
  power_50 = numeric(14),
  power_75 = numeric(14),
  power_100 = numeric(14),
  power_150 = numeric(14),
  power_200 = numeric(14)
  )
power_df$power_10 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_10_comparison.csv")$power
power_df$power_25 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_25_comparison.csv")$power
power_df$power_50 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_50_comparison.csv")$power
power_df$power_75 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_75_comparison.csv")$power
power_df$power_100 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_100_comparison.csv")$power
power_df$power_150 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_150_comparison.csv")$power
power_df$power_200 <- read.csv("data_files/typeIerror_permoob_ttail2_nuisancevar_2_nuisancefeature_200_comparison.csv")$power

power_df$eps <- as.factor(power_df$eps)
colors <- c(
  "10 nuisance features" = "red",
  "25 nuisance features" = "brown",
  "50 nuisance features" = "purple",
  "75 nuisance features" = "green",
  "100 nuisance features" = "blue", 
  "150 nuisance features" = "orange",
  "200 nuisance features" = "black")
png("PermOOB_typeIerror_ttail2_nuisance1.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power_10, color = "10 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_25, color = "25 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_50, color = "50 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_75, color = "75 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_100, color = "100 nuisance features", group = 1), linewidth = 1.75) + 
 geom_line(aes(y = power_150, color = "150 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_200, color = "200 nuisance features", group = 1), linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Type-I error",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("RFPerm: Type-I error T-distribution Noise \n under Varying Noise Level") + 
  scale_y_continuous(limits = c(0, 0.2)) +
    scale_color_manual(values = colors) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


#plots for the PermOOBC:

library(ggplot2)

#Type-I error for LM Model:
power_df <- read.csv("data_files/permOOBC_typeIerror_LM.csv")
png("PermOOBC_typeIerror_LM.png", width = 900, height = 950)
colors <- c("Type-I error cor = 0.0" = "blue","Type-I error cor = 0.2" = "red",
"Type-I error cor = 0.4" = "brown","Type-I error cor = 0.6" = "purple")
power_df$pn_ratio <- c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4)
ggplot(power_df, aes(x = as.factor(pn_ratio))) + 
geom_line(aes(y = cor00, color = "Type-I error cor = 0.0", group = 1), linewidth = 1.75) + 
geom_line(aes(y = cor02, color = "Type-I error cor = 0.2", group = 1), linewidth = 1.75) + 
geom_line(aes(y = cor04, color = "Type-I error cor = 0.4", group = 1), linewidth = 1.75) + 
geom_line(aes(y = cor06, color = "Type-I error cor = 0.6", group = 1), linewidth = 1.75) + 
  scale_color_manual(values = colors) +  labs(x = "p/n",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  scale_y_continuous(limits = c(0, 0.2)) + theme_bw() + 
  ggtitle("RFPerm-C Type-I error Comparison Linear Model, \n n = 500, 8 signal features") +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/permOOBC_typeIerror_Mars.csv")
colors <- c("5 nuisance features" = "red",
  "25 nuisance features" = "blue", 
  "45 nuisance features" = "green",
  "95 nuisance features" = "purple",
  "195 nuisance features" = "brown",
  "495 nuisance features" = "cyan3",
  "995 nuisance features" = "yellow",
  "1995 nuisance features" = "pink")
png("PermOOBC_typeIerror_Mars.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = nuis5, color = "5 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis25, color = "25 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis45, color = "45 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis95, color = "95 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis195, color = "195 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis495, color = "495 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis995, color = "995 nuisance features", group = 1), linewidth = 1.75) + 
geom_line(aes(y = nuis1995, color = "1995 nuisance features", group = 1), linewidth = 1.75) + 
  scale_color_manual(values = colors) +  labs(x = "Noise Level",
       y = "Type-I error",
       color = "Legend") + theme_bw() + 
  scale_y_continuous(limits = c(0, 0.2)) +     
  ggtitle("RFPerm-C Type-I error Comparison Mars Model \n n = 500, 5 signal features") +   
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/permOOBC_typeIerror_longsignal_LM.csv")
colors <- c("Type-I error cor = 0.0" = "red",
  "Type-I error cor = 0.2" = "blue",
  "Type-I error cor = 0.4" = "brown",
  "Type-I error cor = 0.6" = "green")
png("permOOBC_typeIerror_longsignal_LM.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
  geom_line(aes(y = t_cor00, group = 1, color = "Type-I error cor = 0.0"), linewidth = 1.75) + 
  geom_line(aes(y = t_cor02, group = 1, color = "Type-I error cor = 0.2"), linewidth = 1.75) + 
  geom_line(aes(y = t_cor04, group = 1, color = "Type-I error cor = 0.4"), linewidth = 1.75) + 
  geom_line(aes(y = t_cor06, group = 1, color = "Type-I error cor = 0.6"), linewidth = 1.75) + 
  labs(x = "Noise Level", y = "Type-I error", color = "Legend") + theme_bw() + 
   ggtitle("Type-I error for RFPerm-C - \n 100 Signal features, n = 500, p = 200") +   
             guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
               scale_color_manual(values = colors) +   
                 scale_y_continuous(limits = c(0, 0.2)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
    guides(colour = guide_legend(nrow = 3, byrow = TRUE)) +         
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/power_df_cd_benchmark_cor01_conceptdrift1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformal_nn" = "skyblue1",
 "power_conformal_lr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr01_conceptdrift1_rfperm_classification.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.75) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.75) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.75) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.75) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.75) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.75) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  #geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.75) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformal_nn"), linewidth = 1.75) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformal_lr"), linewidth = 1.75) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.75) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.75) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.75) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark for Comparison for RFPerm-C \n Concept Drift Model 1, Corr = 0.1")) +   
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/power_df_cd_benchmark_cor05_conceptdrift2.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  #"power_oob" = "black",
  "power_cf" = "skyblue4",
  "power_autotst" = "red",
 "power_conformal_nn" = "skyblue1",
 "power_conformal_lr" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "red3",
    "power_tst" = "green2"
   # "power_xgb" = "red3",
   # "power_lgb" = "green2"
  )
png("cd_benchmark_corr05_conceptdrift2.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps_seq))) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.75) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.75) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.75) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.75) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.75) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.75) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.75) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformal_nn"), linewidth = 1.75) +  
  geom_line(aes(y = power_conformal_lr, group = 1, color = "power_conformal_lr"), linewidth = 1.75) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.75) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.75) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.75) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +             
  labs(x = "Sigma(Noise) Level", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for RFPerm-C \n Concept Drift Model 2, Corr = 0.5")) +   
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/power_df_CSCD_bothXY.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
  #"power_cf" = "sienna3",
  "power_autotst" = "red",
    "power_conformalnn" = "skyblue3",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
    #"power_xgb" = "red3",
    #"power_lgb" = "blue3"
  )
png("power_df_CSCD_bothXY_meanshift_rfperm.png", width = 900, height = 950)
power_df$mean_shift <- as.factor(power_df$mean_shift)
ggplot(power_df, aes(x = mean_shift)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.75) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.75) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.75) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.75) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.75) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.75) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_conformalnn, group = 1, color = "power_conformalnn"), linewidth = 1.75) +   
  geom_line(aes(y = power_autotst, group = 1, color = "power_autotst"), linewidth = 1.75) +   
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.75) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.75) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.75) +       
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.25) +  
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.25) +         
  labs(x = "Mean Shift", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste(" Mean Shift on top of Concept Drift \n Benchmark Comparison")) +   
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/permOOBC_power_dataqualitydrop1.csv")
colors <- c(
  "power_kmmd" = "blue",
  "power_ctst" = "sienna3",
  "power_chen10" = "brown",
  "power_chen14" = "green",
  "power_sri08" = "orange",
  "power_bai96" = "grey",
  "power_cai14" = "purple",
  "power_skk" = "pink",
  "power_zwlm" = "yellow",
  "power_zwl" = "cyan",
  "power_oob" = "black",
 # "power_cf" = "skyblue4",
  "power_autotst" = "red",
  "power_conformalnn" = "skyblue1",
    "power_pan14" = "violet",
    "power_xu16" = "darkblue",
    "power_miles16" = "springgreen4"
  )
png("permOOBC_power_dataqualitydrop1.png", width = 900, height = 950)
power_df$dif_eps <- as.factor(power_df$dif_eps)
ggplot(power_df, aes(x = dif_eps)) +
  geom_line(aes(y = power_kmmd, group = 1, color = "power_kmmd"), linewidth = 1.75) + 
  geom_line(aes(y = power_ctst, group = 1, color = "power_ctst"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen10, group = 1, color = "power_chen10"), linewidth = 1.75) + 
  geom_line(aes(y = power_chen14, group = 1, color = "power_chen14"), linewidth = 1.75) + 
  geom_line(aes(y = power_sri08, group = 1, color = "power_sri08"), linewidth = 1.75) + 
  geom_line(aes(y = power_bai96, group = 1, color = "power_bai96"), linewidth = 1.75) + 
  geom_line(aes(y = power_cai14, group = 1, color = "power_cai14"), linewidth = 1.75) + 
  geom_line(aes(y = power_skk, group = 1, color = "power_skk"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwlm, group = 1, color = "power_zwlm"), linewidth = 1.75) + 
  geom_line(aes(y = power_zwl, group = 1, color = "power_zwl"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob, group = 1, color = "power_oob"), linewidth = 1.75) + 
  #geom_line(aes(y = power_cf, group = 1, color = "power_cf"), linewidth = 1.25) + 
  geom_line(aes(y = power_tst, group = 1, color = "power_autotst"), linewidth = 1.75) +  
  geom_line(aes(y = power_conformal_nn, group = 1, color = "power_conformalnn"), linewidth = 1.75) +  
  geom_line(aes(y = power_pan14, group = 1, color = "power_pan14"), linewidth = 1.75) +   
  geom_line(aes(y = power_xu16, group = 1, color = "power_xu16"), linewidth = 1.75) +     
  geom_line(aes(y = power_miles16, group = 1, color = "power_miles16"), linewidth = 1.75) +           
  #geom_line(aes(y = power_xgb, group = 1, color = "power_xgb"), linewidth = 1.75) +     
  #geom_line(aes(y = power_lgb, group = 1, color = "power_lgb"), linewidth = 1.75) +             
  labs(x = "Epsilon Difference", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Benchmark Comparison for Existing Methods \n Data Quality Drop - Binary Response")) +   
guides(colour = guide_legend(nrow = 6, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 29), 
        legend.text = element_text(size = 29)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- data.frame(
  pn_ratio = c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4),
  powereps0.1 = numeric(13),
  powereps1 = numeric(13),
  powereps2 = numeric(13),
  powereps5 = numeric(13),
  powereps10 = numeric(13),
  powereps20 = numeric(13)
  )
nuis_seq <- c(5, 15, 25, 35, 45, 95, 145, 195, 295, 495, 995, 1495, 1995)
for(i in 1:13){
  pdf <- read.csv(paste("data_files/permOOBC_conceptdrift1_power_nuisancefeature", 
    nuis_seq[i], "nuisance_eps_2.csv", sep = "_"))
  df$powereps0.1[i] <- pdf$power[1]
  df$powereps1[i] <- pdf$power[4]
  df$powereps2[i] <- pdf$power[5]
  df$powereps5[i] <- pdf$power[7]
  df$powereps10[i] <- pdf$power[9]
  df$powereps20[i] <- pdf$power[11]
}

png("permOOBC_ttail_nuisance_eps2.png", width = 900, height = 950)
colors <- c("power eps = 0.1" = "red",
            "power eps = 1" = "blue",
            "power eps = 2" = "brown",
            "power eps = 5" = "green",
            "power eps = 10" = "cyan3",
            "power eps = 20" = "black")
ggplot(df, aes(x = as.factor(pn_ratio))) + 
  geom_line(aes(y = powereps0.1, group = 1, color = "power eps = 0.1"), linewidth = 1.75) + 
  geom_line(aes(y = powereps1, group = 1, color = "power eps = 1"), linewidth = 1.75) + 
  geom_line(aes(y = powereps2, group = 1, color = "power eps = 2"), linewidth = 1.75) + 
  geom_line(aes(y = powereps5, group = 1, color = "power eps = 5"), linewidth = 1.75) + 
  geom_line(aes(y = powereps10, group = 1, color = "power eps = 10"), linewidth = 1.75) + 
  geom_line(aes(y = powereps20, group = 1, color = "power eps = 20"), linewidth = 1.75) +   
  labs(x = "p/n", y = "Power", color = "Legend") + 
   ggtitle("Power for RFPerm-C T-Distribution Noise df = 2") +   
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


df <- data.frame(
  pn_ratio = c(0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.6, 1, 2, 3, 4),
  powereps0.1 = numeric(13),
  powereps1 = numeric(13),
  powereps2 = numeric(13),
  powereps5 = numeric(13),
  powereps10 = numeric(13),
  powereps20 = numeric(13)
  )
nuis_seq <- c(5, 15, 25, 35, 45, 95, 145, 195, 295, 495, 995, 1495, 1995)
for(i in 1:13){
  pdf <- read.csv(paste("data_files/permOOBC_conceptdrift1_power_nuisancefeature", 
    nuis_seq[i], "nuisance_eps_3.csv", sep = "_"))
  df$powereps0.1[i] <- pdf$power[1]
  df$powereps1[i] <- pdf$power[4]
  df$powereps2[i] <- pdf$power[5]
  df$powereps5[i] <- pdf$power[7]
  df$powereps10[i] <- pdf$power[9]
  df$powereps20[i] <- pdf$power[11]
}
df <- read.csv("data_files/permOOBC_ttail_sigma3.csv")
png("permOOBC_ttail_nuisance_eps3.png", width = 900, height = 950)
colors <- c("power eps = 0.1" = "red",
            "power eps = 1" = "blue",
            "power eps = 2" = "brown",
            "power eps = 5" = "green",
            "power eps = 10" = "cyan3",
            "power eps = 20" = "black")
ggplot(df, aes(x = as.factor(pn_ratio))) + 
  geom_line(aes(y = powereps0.1, group = 1, color = "power eps = 0.1"), linewidth = 1.75) + 
  geom_line(aes(y = powereps1, group = 1, color = "power eps = 1"), linewidth = 1.75) + 
  geom_line(aes(y = powereps2, group = 1, color = "power eps = 2"), linewidth = 1.75) + 
  geom_line(aes(y = powereps5, group = 1, color = "power eps = 5"), linewidth = 1.75) + 
  geom_line(aes(y = powereps10, group = 1, color = "power eps = 10"), linewidth = 1.75) + 
  geom_line(aes(y = powereps20, group = 1, color = "power eps = 20"), linewidth = 1.75) +   
  labs(x = "p/n", y = "Power", color = "Legend") + theme_bw() + 
   ggtitle("Power for RFPerm-C T-Distribution Noise df = 3") +   
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- data.frame(
  mean_shift = seq(0, 3, 0.2)
  )
power_df$power1 <- read.csv("data_files/PermOOB_Power_Sigma_4_SensitivityMeanShift.csv")$power
power_df$power2 <- read.csv("data_files/PermOOB_Power_Sigma_7_SensitivityMeanShift.csv")$power
power_df$power3 <- read.csv("data_files/PermOOB_Power_Sigma_8_SensitivityMeanShift.csv")$power
power_df$power4 <- read.csv("data_files/PermOOB_Power_Sigma_9_SensitivityMeanShift.csv")$power
power_df$power5 <- read.csv("data_files/PermOOB_Power_Sigma_10_SensitivityMeanShift.csv")$power
power_df$power6 <- read.csv("data_files/PermOOB_Power_Sigma_11_SensitivityMeanShift.csv")$power
colors = c("sigma = 1" = "red",
           "sigma = 5" = "blue",
           "sigma = 7.5" = "green",
           "sigma = 10" = "orange",
           "sigma = 15" = "brown",
           "sigma = 20" = "black")
png('permoob_power_conceptdrift_meansensitivity.png', width = 900, height = 950)
power_df$mean_shift <- as.factor(power_df$mean_shift)
ggplot(power_df, aes(x = mean_shift)) +
  geom_line(aes(y = power1, group = 1, color = "sigma = 1"), linewidth = 1.75) + 
  geom_line(aes(y = power2, group = 1, color = "sigma = 5"), linewidth = 1.75) + 
  geom_line(aes(y = power3, group = 1, color = "sigma = 7.5"), linewidth = 1.75) + 
  geom_line(aes(y = power4, group = 1, color = "sigma = 10"), linewidth = 1.75) + 
  geom_line(aes(y = power5, group = 1, color = "sigma = 15"), linewidth = 1.75) + 
  geom_line(aes(y = power6, group = 1, color = "sigma = 20"), linewidth = 1.75) + 
  labs(x = "Mean Shift", y = "Power", color = "Legend") + 
  scale_color_manual(values = colors) + theme_bw() + 
  ggtitle("RFPerm: Power for Covariateshift on top of \n Concept Drift - Mean Shift Sensitivity") +       
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

power_df <- data.frame(
  var_shift = seq(0.2, 3, 0.2)
  )

power_df$power1 <- read.csv("data_files/PermOOB_Power_Sigma_4_SensitivityVarianceShift.csv")$power
power_df$power2 <- read.csv("data_files/PermOOB_Power_Sigma_7_SensitivityVarianceShift.csv")$power
power_df$power3 <- read.csv("data_files/PermOOB_Power_Sigma_8_SensitivityVarianceShift.csv")$power
power_df$power4 <- read.csv("data_files/PermOOB_Power_Sigma_9_SensitivityVarianceShift.csv")$power
power_df$power5 <- read.csv("data_files/PermOOB_Power_Sigma_10_SensitivityVarianceShift.csv")$power
power_df$power6 <- read.csv("data_files/PermOOB_Power_Sigma_11_SensitivityVarianceShift.csv")$power
colors = c("sigma = 1" = "red",
           "sigma = 5" = "blue",
           "sigma = 7.5" = "green",
           "sigma = 10" = "orange",
           "sigma = 15" = "brown",
           "sigma = 20" = "black")
png('permoob_power_conceptdrift_variancesensitivity.png', width = 900, height = 950)
power_df$var_shift <- as.factor(power_df$var_shift)
ggplot(power_df, aes(x = var_shift)) +
  geom_line(aes(y = power1, group = 1, color = "sigma = 1"), linewidth = 1) + 
  geom_line(aes(y = power2, group = 1, color = "sigma = 5"), linewidth = 1) + 
  geom_line(aes(y = power3, group = 1, color = "sigma = 7.5"), linewidth = 1) + 
  geom_line(aes(y = power4, group = 1, color = "sigma = 10"), linewidth = 1) + 
  geom_line(aes(y = power5, group = 1, color = "sigma = 15"), linewidth = 1) + 
  geom_line(aes(y = power6, group = 1, color = "sigma = 20"), linewidth = 1) +   
  labs(x = "Variance Shift", y = "Power", color = "Legend") + theme_bw() + 
  ggtitle("RFPerm: Power for Covariateshift on top of \n Concept Drift - Variance Shift Sensitivity") +       
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



#robustness w.r.t. tuning:
sigma_seq <- c(0.1, 0.2, 0.5, 0.75, 1, 1.5, 2, 3, 5, 10, 20, 30, 50, 100)
power_df <- data.frame(
  sigma = sigma_seq,
  t1e_nontune = numeric(14),
  t1e_mtrytune = numeric(14),
  t1e_minnodetune = numeric(14),
  t1e_wholetune = numeric(14))
power_df$t1e_nontune <- read.csv("data_files/typeIerror_permOOB_Mars_notune.csv")$power
power_df$t1e_mtrytune <- read.csv("data_files/typeIerror_permOOB_Mars_mtrytune.csv")$power
power_df$t1e_minnodetune <- read.csv("data_files/typeIerror_permOOB_Mars_minnodetune.csv")$power
power_df$t1e_wholetune <- read.csv("data_files/typeIerror_permOOB_Mars_wholetune.csv")$power
png("typeIerror_permOOB_tuning_Mars_comparison.png", width = 900, height = 950)
colors <- c("non_tuning" = "blue", "mtry_tuning" = "red",
  "minnode_tuning" = "black", "whole_tuning" = "orange")
ggplot(power_df, aes(x = as.factor(sigma))) + 
geom_line(aes(y = t1e_nontune, color = "non_tuning", group = 1), linewidth = 1.75) + 
geom_line(aes(y = t1e_mtrytune, color = "mtry_tuning", group = 1), linewidth = 1.75) + 
geom_line(aes(y = t1e_minnodetune, color = "minnode_tuning", group = 1), linewidth = 1.75) + 
geom_line(aes(y = t1e_wholetune, color = "whole_tuning", group = 1), linewidth = 1.75) + 
scale_color_manual(values = colors) + theme_bw() + 
labs(x = "Sigma", y = "typeIerror") + ggtitle("Type-I error Comparison for Mars Model Tuning") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 0.3)) +     
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- data.frame(
  eps = eps_seq,
  power2 = numeric(14),
  power5 = numeric(14),
  power10 = numeric(14),
  power15 = numeric(14),
  power30 = numeric(14),
  power50 = numeric(14)
  )
power_df$power2 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_2_nuisancefeature_50_comparison.csv")$power
power_df$power5 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_5_nuisancefeature_50_comparison.csv")$power
power_df$power10 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_10_nuisancefeature_50_comparison.csv")$power
power_df$power15 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_15_nuisancefeature_50_comparison.csv")$power
power_df$power30 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_30_nuisancefeature_50_comparison.csv")$power
power_df$power50 <- read.csv("data_files/power_permoob_ttail2_nuisancevar_50_nuisancefeature_50_comparison.csv")$power
colors <- c(
  "var = 2" = "red",
  "var = 5" = "brown",
  "var = 10" = "purple",
  "var = 15" = "green",
  "var = 30" = "blue", 
  "var = 50" = "black")
png("PermOOB_power_ttail2_nuisance50.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power2, color = "var = 2", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power5, color = "var = 5", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power10, color = "var = 10", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power15, color = "var = 15", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power30, color = "var = 30", group = 1),linewidth = 1.75) + 
 geom_line(aes(y = power50, color = "var = 50", group = 1),linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() + 
ggtitle("RFPerm: Concept Drift 2 T-distribution \n with Varying Noise, n = 500, p = 50") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

missing_prop_seq <- seq(0, 0.6, 0.05)
power_df <- data.frame(
  eps = eps_seq,
  power5 = numeric(14),
  power15 = numeric(14),
  power25 = numeric(14),
  power35 = numeric(14),
  power45 = numeric(14),
  power55 = numeric(14),
  power60 = numeric(14)
  )
power_df$power5 <- read.csv("data_files/power_permoob_conceptdrift1_0.05_missingratio.csv")$power
power_df$power15 <- read.csv("data_files/power_permoob_conceptdrift1_0.15_missingratio.csv")$power
power_df$power25 <- read.csv("data_files/power_permoob_conceptdrift1_0.25_missingratio.csv")$power
power_df$power35 <- read.csv("data_files/power_permoob_conceptdrift1_0.35_missingratio.csv")$power
power_df$power45 <- read.csv("data_files/power_permoob_conceptdrift1_0.45_missingratio.csv")$power
power_df$power55 <- read.csv("data_files/power_permoob_conceptdrift1_0.55_missingratio.csv")$power
power_df$power60 <- read.csv("data_files/power_permoob_conceptdrift1_0.6_missingratio.csv")$power
power_df$eps <- as.factor(power_df$eps)
colors <- c("missing 5%" = "red",
  "missing 15%" = "blue",
  "missing 25%" = "brown",
  "missing 35%" = "purple",
  "missing 45%" = "green",
  "missing 55%" = "orange",
  "missing 60%" = "cyan3")
png("PermOOB_conceptdrift1_missingratio_eps.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power5, color = "missing 5%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power15, color = "missing 15%", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power25, color = "missing 25%", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power35, color = "missing 35%", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power45, color = "missing 45%", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power55, color = "missing 55%", group = 1),linewidth = 1.75) + 
geom_line(aes(y = power60, color = "missing 60%", group = 1),linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("RFPerm: Concept Drift 1, n = 500, varying missing ratio") + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



missing_prop_seq <- seq(0, 0.6, 0.05)
power_df <- data.frame(
  eps = eps_seq,
  power5 = numeric(14),
  power15 = numeric(14),
  power25 = numeric(14),
  power35 = numeric(14),
  power45 = numeric(14),
  power55 = numeric(14),
  power60 = numeric(14)
  )
power_df$power5 <- read.csv("data_files/power_permoob_conceptdrift2_0.05_missingratio.csv")$power
power_df$power15 <- read.csv("data_files/power_permoob_conceptdrift2_0.15_missingratio.csv")$power
power_df$power25 <- read.csv("data_files/power_permoob_conceptdrift2_0.25_missingratio.csv")$power
power_df$power35 <- read.csv("data_files/power_permoob_conceptdrift2_0.35_missingratio.csv")$power
power_df$power45 <- read.csv("data_files/power_permoob_conceptdrift2_0.45_missingratio.csv")$power
power_df$power55 <- read.csv("data_files/power_permoob_conceptdrift2_0.55_missingratio.csv")$power
power_df$power60 <- read.csv("data_files/power_permoob_conceptdrift2_0.6_missingratio.csv")$power
power_df$eps <- as.factor(power_df$eps)
colors <- c("missing ratio 5%" = "red",
  "missing ratio 15%" = "blue",
  "missing ratio 25%" = "brown",
  "missing ratio 35%" = "purple",
  "missing ratio 45%" = "green",
  "missing ratio 55%" = "orange",
  "missing ratio 60%" = "cyan3")
png("PermOOB_conceptdrift2_missingratio_eps.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power5, color = "missing ratio 5%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power15, color = "missing ratio 15%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power25, color = "missing ratio 25%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power35, color = "missing ratio 35%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power45, color = "missing ratio 45%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power55, color = "missing ratio 55%", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power60, color = "missing ratio 60%", group = 1), linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("RFPerm: Concept Drift 2, n = 500, varying missing ratio") + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()




missing_prop_seq <- seq(0, 0.6, 0.05)
power_df <- data.frame(
  eps = eps_seq,
  power5 = numeric(14),
  power15 = numeric(14),
  power25 = numeric(14),
  power35 = numeric(14),
  power45 = numeric(14),
  power55 = numeric(14)
  )
power_df$power5 <- read.csv("data_files/power_permoob_conceptdrift2_0.05_missingratio_pn1.csv")$power
power_df$power15 <- read.csv("data_files/power_permoob_conceptdrift2_0.15_missingratio_pn1.csv")$power
power_df$power25 <- read.csv("data_files/power_permoob_conceptdrift2_0.25_missingratio_pn1.csv")$power
power_df$power35 <- read.csv("data_files/power_permoob_conceptdrift2_0.35_missingratio_pn1.csv")$power
power_df$power45 <- read.csv("data_files/power_permoob_conceptdrift2_0.45_missingratio_pn1.csv")$power
power_df$power55 <- read.csv("data_files/power_permoob_conceptdrift2_0.55_missingratio_pn1.csv")$power
power_df$eps <- as.factor(power_df$eps)
colors <- c("missing ratio 5%" = "red",
  "missing ratio 15%" = "blue",
  "missing ratio 25%" = "brown",
  "missing ratio 35%" = "purple",
  "missing ratio 45%" = "green",
  "missing ratio 55%" = "orange")
png("PermOOB_conceptdrift2_missingratio_eps_pn1.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power5, color = "missing ratio 5%", group = 1), linewidth = 1) + 
geom_line(aes(y = power15, color = "missing ratio 15%", group = 1),linewidth = 1) + 
geom_line(aes(y = power25, color = "missing ratio 25%", group = 1),linewidth = 1) + 
geom_line(aes(y = power35, color = "missing ratio 35%", group = 1),linewidth = 1) + 
geom_line(aes(y = power45, color = "missing ratio 45%", group = 1),linewidth = 1) + 
geom_line(aes(y = power55, color = "missing ratio 55%", group = 1), linewidth = 1) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("RFPerm: Concept Drift 2, n = 500, p/n = 1, varying missing ratio") + 
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/1_SNRdrop_LM_permOOB_new_bi_direc.csv")
power_df2 <- read.csv("data_files/2_SNRdrop_LM_permOOB_new_bi_direc.csv")
power_df3 <- read.csv("data_files/3_SNRdrop_LM_permOOB_new_bi_direc.csv")
power_df$SNR1_1 <- power_df$power_dir1
power_df$SNR1_2 <- power_df$power_dir2
power_df$SNR2_1 <- power_df2$power_dir1
power_df$SNR2_2 <- power_df2$power_dir2
power_df$SNR3_1 <- power_df3$power_dir1
power_df$SNR3_2 <- power_df3$power_dir2

colors <- c("SNR = 1 Increase Bi-Dir" = "red",
            "SNR = 1 Increase One-Dir" = "blue",
            "SNR = 2 Increase Bi-Dir" = "orange",
            "SNR = 2 Increase One-Dir" = "green",
            "SNR = 3 Increase Bi-Dir" = "brown",
            "SNR = 3 Increase One-Dir" = "black")
png('dataquality_drop_Bidirection.png', width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(dif_snr))) + 
  geom_line(aes(y = SNR1_1, group = 1, color = "SNR = 1 Increase Bi-Dir"), linewidth = 1.75) + 
  geom_line(aes(y = SNR1_2, group = 1, color = "SNR = 1 Increase One-Dir"), linewidth = 1.75) + 
  geom_line(aes(y = SNR2_1, group = 1, color = "SNR = 2 Increase Bi-Dir"), linewidth = 1.75) + 
  geom_line(aes(y = SNR2_2, group = 1, color = "SNR = 2 Increase One-Dir"), linewidth = 1.75) + 
  geom_line(aes(y = SNR3_1, group = 1, color = "SNR = 3 Increase Bi-Dir"), linewidth = 1.75) + 
  geom_line(aes(y = SNR3_2, group = 1, color = "SNR = 3 Increase One-Dir"), linewidth = 1.75) +   
  labs(x = "SNR Difference", y = "Power", color = "Legend") + 
ggtitle("Power PermOOB Data Quality Difference Linear Model \n One-Directional vs. Bidirectional Procedure") +                                                     
guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 8)/500
result_df <- data.frame(
  pn_ratio = pn_ratio,
  typeIerror1 = numeric(17),
  power1 = numeric(17),
  typeIerror2 = numeric(17),
  power2 = numeric(17),
  typeIerror3 = numeric(17),
  power3 = numeric(17),
  typeIerror4 = numeric(17),
  power4 = numeric(17)
  )
t1_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
t2_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
t3_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
t4_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
power_df1 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
power_df2 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
power_df3 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
power_df4 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
result_df$typeIerror1 <- t1_df$power
result_df$typeIerror2 <- t2_df$power
result_df$power1 <- power_df1$power 
result_df$power2 <- power_df2$power
result_df$typeIerror3 <- t3_df$power
result_df$typeIerror4 <- t4_df$power
result_df$power3 <- power_df3$power 
result_df$power4 <- power_df4$power

png("permoob_highdim_pn_power1.png", width = 900, height = 950)
colors <- c("power cor0.0" = "red", "power cor0.2" = "blue",
  "power cor0.4" = "orange", "power cor0.6" = "brown")
ggplot(result_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
  geom_line(aes(y = power1, color = "power cor0.0", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power2, color = "power cor0.2", group = 1), linewidth = 1.75) +
  geom_line(aes(y = power3, color = "power cor0.4", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power4, color = "power cor0.6", group = 1), linewidth = 1.75) +  
  scale_color_manual(values = colors) +  
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +   
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + theme_bw() + 
  ggtitle("Power for Concept Drift - High-Dimensional Comparison, n = 500") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

png("permoob_highdim_pn_typeIerror1.png", width = 900, height = 950)
colors <- c("typeIerror_conceptdrift2_cor00" = "red", "typeIerror_conceptdrift2_cor02" = "blue",
  "typeIerror_conceptdrift2_cor04" = "orange", "typeIerror_conceptdrift2_cor06" = "brown")
ggplot(result_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
  geom_line(aes(y = typeIerror1, color = "typeIerror_conceptdrift2_cor00", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = typeIerror2, color = "typeIerror_conceptdrift2_cor02", group = 1), linewidth = 1.75) +
  geom_line(aes(y = typeIerror3, color = "typeIerror_conceptdrift2_cor04", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = typeIerror4, color = "typeIerror_conceptdrift2_cor06", group = 1), linewidth = 1.75) + 
  scale_color_manual(values = colors) +  labs(x = "p/n",
       y = "Type-I error",
       color = "Legend") + 
  ggtitle("Type-I error for Concept Drift - High-Dimensional Comparison, n = 500") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 5)/500
power_df <- data.frame(
  pn_ratio = pn_ratio,
  power_covariateshiftonly1 = numeric(17),
  power_covariateshiftonly2 = numeric(17),
  power_covariateshiftonly3 = numeric(17)
  )
power_csonly1 <- read.csv("data_files/power_covariateshiftonly1_nuisance_Mars.csv")
power_csonly2 <- read.csv("data_files/power_covariateshiftonly2_nuisance_Mars.csv")
power_csonly3 <- read.csv("data_files/power_covariateshiftonly3_nuisance_Mars.csv")
#draw the curves here.
power_df$power_covariateshiftonly1 <- power_csonly1$power 
power_df$power_covariateshiftonly2 <- power_csonly2$power 
power_df$power_covariateshiftonly3 <- power_csonly3$power 
png("permoob_pn_ratio_covariateshiftonly_power1.png", width = 900, height = 950)
colors <- c("Power C.S. Only Case 1" = "red", 
  "Power C.S. Only Case 2" = "blue",
  "Power C.S. Only Case 3" = "orange")
ggplot(power_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
geom_line(aes(y = power_covariateshiftonly1, color = "Power C.S. Only Case 1", group = 1),
  linewidth = 1.75) + 
geom_line(aes(y = power_covariateshiftonly2, color = "Power C.S. Only Case 2", group = 1),
  linewidth = 1.75) + 
geom_line(aes(y = power_covariateshiftonly3, color = "Power C.S. Only Case 3", group = 1),
  linewidth = 1.75) + scale_color_manual(values = colors) +  
  guides(colour = guide_legend(nrow = 3, byrow = TRUE)) + theme_bw() + 
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + 
  ggtitle("Power for Covariate Shift Only \n High-Dimensional Comparison, n = 500") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 8)/500
power_df1 <- read.csv("data_files/power_permoob_conceptdrift1_nuisance_highnoisefeature_corr_0_eps.csv")
power_df2 <- read.csv("data_files/power_permoob_conceptdrift1_nuisance_highnoisefeature_corr_0.2_eps.csv")
power_df3 <- read.csv("data_files/power_permoob_conceptdrift1_nuisance_highnoisefeature_corr_0.4_eps.csv")
power_df4 <- read.csv("data_files/power_permoob_conceptdrift1_nuisance_highnoisefeature_corr_0.6_eps.csv")
power_df <- data.frame(
  pn_ratio = pn_ratio,
  power_cor00 = numeric(17),
  power_cor02 = numeric(17),
  power_cor04 = numeric(17),
  power_cor06 = numeric(17)
  )
power_df$power_cor00 = power_df1$power 
power_df$power_cor02 = power_df2$power 
power_df$power_cor04 = power_df3$power 
power_df$power_cor06 = power_df4$power
png("permoob_pn_ratio_nuisance_highnoisefeature1.png", width = 900, height = 950)
colors <- c("power_cor00" = "red", 
  "power_cor02" = "blue",
  "power_cor04" = "orange",
  "power_cor06" = "purple")
ggplot(power_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
geom_line(aes(y = power_cor00, color = "power_cor00", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_cor02, color = "power_cor02", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_cor04, color = "power_cor04", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_cor06, color = "power_cor06", group = 1), linewidth = 1.75) + 
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + 
  ggtitle("Power for Noise Nuisance Features \n High-Dimensional Comparison, n = 500") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 8)/500
power_df1 <- read.csv("data_files/permOOB_1_varianceshiftsensitivity_highdim_pn_ratio_power.csv")
power_df2 <- read.csv("data_files/permOOB_5_varianceshiftsensitivity_highdim_pn_ratio_power.csv")
power_df3 <- read.csv("data_files/permOOB_9_varianceshiftsensitivity_highdim_pn_ratio_power.csv")
power_df4 <- read.csv("data_files/permOOB_13_varianceshiftsensitivity_highdim_pn_ratio_power.csv")

power_df <- data.frame(
  pn_ratio = pn_ratio,
  power_sigma1 = numeric(17),
  power_sigma5 = numeric(17),
  power_sigma9 = numeric(17),
  power_sigma13 = numeric(17)
  )
power_df$power_sigma1 = power_df1$power 
power_df$power_sigma5 = power_df2$power 
power_df$power_sigma9 = power_df3$power
power_df$power_sigma13 = power_df4$power
png("permoob_varianceshift_pn_ratio_mars1.png", width = 900, height = 950)
colors <- c("power sigma = 0.1" = "red", 
  "power sigma = 2" = "blue",
  "power sigma = 10" = "orange",
  "power sigma = 50" = "black")
ggplot(power_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
geom_line(aes(y = power_sigma1, color = "power sigma = 0.1", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_sigma5, color = "power sigma = 2", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_sigma9, color = "power sigma = 10", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power_sigma13, color = "power sigma = 50", group = 1), linewidth = 1.75) + 
  scale_color_manual(values = colors) +
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +   
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + theme_bw() + 
  ggtitle("Power for Variance Shift on top of Concept Drift \n High-Dimensional Comparison, n = 500") + 
guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 0.5)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 32)) + 
   theme(axis.title = element_text(size = 32)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 31), 
        legend.text = element_text(size = 31)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/power_perm_samplesizeratio_conceptdrift_bi_adjustment.csv")
colors <- c(
"power oob" = "red",
"power oob bidir" = "blue",
"power xgb" = "purple",
"power xgb bidir" = "orange",
"power lgb" = "green",
"power lgb bidir" = "black"
  )
png("power_perm_samplesizeratio_conceptdrift_bidirectional.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_oob, group = 1, color = "power oob"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob_bi, group = 1, color = "power oob bidir"), linewidth = 1.75) + 
  #geom_line(aes(y = power_xgb, group = 1, color = "power xgb"), linewidth = 1.25) + 
  #geom_line(aes(y = power_xgb_bi, group = 1, color = "power xgb bidir"), linewidth = 1.25) + 
  #geom_line(aes(y = power_lgb, group = 1, color = "power lgb"), linewidth = 1.25) + 
  #geom_line(aes(y = power_lgb_bi, group = 1, color = "power lgb bidir"), linewidth = 1.25) + 
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for RFPerm - Varying Sample size ratio \n Concept Drift Model 1") +   
guides(colour = guide_legend(nrow = 1, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/typeIerror_permxgboob_samplesizeratio_covariateshift_bi.csv")
colors <- c(
"power oob for" = "red",
'power oob rev' = 'orange',
"power oob bidir" = "blue",
"power xgb" = "purple",
"power xgb bidir" = "orange",
"power lgb" = "green",
"power lgb bidir" = "black"
  )
png("typeIerror_perm_samplesizeratio_covariateshift_bidirectional.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_oob, group = 1, color = "power oob for"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob_rev, group = 1, color = "power oob rev"), linewidth = 1.75) + 
  geom_line(aes(y = power_oob_bi, group = 1, color = "power oob bidir"), linewidth = 1.75) +
  #geom_line(aes(y = power_xgb, group = 1, color = "power xgb"), linewidth = 1.25) + 
  #geom_line(aes(y = power_xgb_bi, group = 1, color = "power xgb bidir"), linewidth = 1.25) + 
  #geom_line(aes(y = power_lgb, group = 1, color = "power lgb"), linewidth = 1.25) + 
  #geom_line(aes(y = power_lgb_bi, group = 1, color = "power lgb bidir"), linewidth = 1.25) + 
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Type-I Error", color = "Legend") + theme_bw() + 
ggtitle("Type-I error for RFPerm - Varying Sample size ratio \n Concept Drift Model 1") +   
guides(colour = guide_legend(nrow = 1, byrow = TRUE)) + 
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 0.2)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("power_perm_samplesizeratio_covariateshift_bi_adjustment.csv")
colors <- c(
"power oob" = "red",
"power oob bidir" = "blue",
"power xgb" = "purple",
"power xgb bidir" = "orange",
"power lgb" = "green",
"power lgb bidir" = "black"
  )
png("power_perm_samplesizeratio_covariateshift_bidirectional.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_oob, group = 1, color = "power oob"), linewidth = 1.25) + 
  geom_line(aes(y = power_oob_bi, group = 1, color = "power oob bidir"), linewidth = 1.25) + 
  geom_line(aes(y = power_xgb, group = 1, color = "power xgb"), linewidth = 1.25) + 
  geom_line(aes(y = power_xgb_bi, group = 1, color = "power xgb bidir"), linewidth = 1.25) + 
  geom_line(aes(y = power_lgb, group = 1, color = "power lgb"), linewidth = 1.25) + 
  geom_line(aes(y = power_lgb_bi, group = 1, color = "power lgb bidir"), linewidth = 1.25) + 
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying sample size ratio \n Covariate Shift: Both Mean Shift and Variance Shift") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


nuisance_seq <- c(12, 42, 92, 142, 192,
  242, 292, 392, 492, 742, 992, 1242, 1492, 1992, 2992, 3992, 4992)
pn_ratio <- (nuisance_seq + 8)/500
result_df <- data.frame(
  pn_ratio = pn_ratio,
  typeIerror1 = numeric(17),
  power1 = numeric(17),
  typeIerror2 = numeric(17),
  power2 = numeric(17),
  typeIerror3 = numeric(17),
  power3 = numeric(17),
  typeIerror4 = numeric(17),
  power4 = numeric(17)
  )
t1_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
t2_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
t3_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
t4_df <- read.csv("data_files/typeIerror_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
power_df1 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0_eps.csv")
power_df2 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.2_eps.csv")
power_df3 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.4_eps.csv")
power_df4 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_corr_0.6_eps.csv")
result_df$typeIerror1 <- t1_df$power
result_df$typeIerror2 <- t2_df$power
result_df$power1 <- power_df1$power 
result_df$power2 <- power_df2$power
result_df$typeIerror3 <- t3_df$power
result_df$typeIerror4 <- t4_df$power
result_df$power3 <- power_df3$power 
result_df$power4 <- power_df4$power
write.csv(result_df, "power_conceptdrift2_")

png("permoob_highdim_pn_power1.png", width = 900, height = 950)
colors <- c("power cor0.0" = "red", "power cor0.2" = "blue",
  "power cor0.4" = "orange", "power cor0.6" = "brown")
ggplot(result_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
  geom_line(aes(y = power1, color = "power cor0.0", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power2, color = "power cor0.2", group = 1), linewidth = 1.75) +
  geom_line(aes(y = power3, color = "power cor0.4", group = 1), linewidth = 1.75) + 
  geom_line(aes(y = power4, color = "power cor0.6", group = 1), linewidth = 1.75) +  
  scale_color_manual(values = colors) +  
  guides(colour = guide_legend(nrow = 2, byrow = TRUE)) +   
  labs(x = "p/n",
       y = "Power",
       color = "Legend") + theme_bw() + 
  ggtitle("Power for Concept Drift - High-Dimensional Comparison, n = 500") + 
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

png("permoob_highdim_pn_typeIerror1.png", width = 900, height = 950)
colors <- c("typeIerror_conceptdrift2_cor00" = "red", "typeIerror_conceptdrift2_cor02" = "blue",
  "typeIerror_conceptdrift2_cor04" = "orange", "typeIerror_conceptdrift2_cor06" = "brown")
ggplot(result_df, aes(x = as.factor(round(pn_ratio, 1)))) + 
  geom_line(aes(y = typeIerror1, color = "typeIerror_conceptdrift2_cor00", group = 1), linewidth = 1) + 
  geom_line(aes(y = typeIerror2, color = "typeIerror_conceptdrift2_cor02", group = 1), linewidth = 1) +
  geom_line(aes(y = typeIerror3, color = "typeIerror_conceptdrift2_cor04", group = 1), linewidth = 1) + 
  geom_line(aes(y = typeIerror4, color = "typeIerror_conceptdrift2_cor06", group = 1), linewidth = 1) + 
  scale_color_manual(values = colors) +  labs(x = "p/n",
       y = "Type-I error",
       color = "Legend") + 
  ggtitle("Type-I error for Concept Drift - High-Dimensional Comparison, n = 500") + 
scale_y_continuous(limits = c(0, 0.25)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

eps_seq <- c(0.1, 0.2, 0.5, 1, 2, 3, 5, 7.5, 10, 15, 20, 30, 50, 100)
power_df <- data.frame(
  eps = eps_seq,
  power20 = numeric(14),
  power50 = numeric(14),
  power150 = numeric(14),
  power500 = numeric(14),
  power2000 = numeric(14)
  )
power_df$power20 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_12_eps.csv")$power
power_df$power50 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_42_eps.csv")$power
power_df$power150 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_142_eps.csv")$power
power_df$power500 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_492_eps.csv")$power
power_df$power2000 <- read.csv("data_files/power_permoob_conceptdrift2_nuisance_1992_eps.csv")$power
power_df$eps <- as.factor(power_df$eps)
colors <- c("p/n = 0.04" = "red",
  "p/n = 0.1" = "blue",
  "p/n = 0.3" = "brown",
  "p/n = 1" = "purple",
  "p/n = 4" = "green")
png("PermOOB_conceptdrift2_Nuisance_eps.png", width = 900, height = 950)
ggplot(power_df, aes(x = as.factor(eps))) + 
geom_line(aes(y = power20, color = "p/n = 0.04", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power50, color = "p/n = 0.1", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power150, color = "p/n = 0.3", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power500, color = "p/n = 1", group = 1), linewidth = 1.75) + 
geom_line(aes(y = power2000, color = "p/n = 4", group = 1), linewidth = 1.75) + 
scale_color_manual(values = colors) + labs(
  x = "Noise Level",
  y = "Power",
  color = "Legend"
  ) + theme_bw() + 
  ggtitle("RFPerm: Concept Drift 2, n = 500,\n corr = 0.3, varying dimensions") + 
    scale_color_manual(values = colors) + 
    scale_y_continuous(limits = c(0, 1)) +  
    guides(colour = guide_legend(nrow = 2, byrow = TRUE)) + 
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()







power_df <- read.csv("data_files/rfperm_samplesize_typeIerror.csv")
colors <- c(
"power bidirectional" = "red",
"power forward" = "blue",
"power backward" = "orange"
  )
png("typeIerror_perm_cs_bidir_covarshift.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
  geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
  geom_line(aes(y = power_back, group = 1, color = "power backward"), linewidth = 1.75) +  
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying sample size ratio \n Type-I error: Bidirectional Procedure") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 0.25)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



power_df <- read.csv("data_files/rfperm_samplesize_varianceshift.csv")
colors <- c(
"power bidirectional" = "red",
"power forward" = "blue",
"power backward" = "orange"
  )
png("rfperm_samplesize_varianceshift.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
  geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
  geom_line(aes(y = power_back, group = 1, color = "power backward"), linewidth = 1.75) +  
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying sample size ratio \n Variance Shift") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()

power_df <- read.csv("data_files/rfperm_samplesize_meanshift.csv")
colors <- c(
"power bidirectional" = "red",
"power forward" = "blue",
"power backward" = "orange"
  )
png("rfperm_samplesize_meanshift.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
  geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
  geom_line(aes(y = power_back, group = 1, color = "power backward"), linewidth = 1.75) +  
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying sample size ratio \n Mean Shift") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


power_df <- read.csv("data_files/rfperm_samplesize_conceptdrift.csv")
colors <- c(
"power bidirectional" = "red",
"power forward" = "blue",
"power backward" = "orange"
  )
png("rfperm_samplesize_conceptdrift.png", width = 900, height = 950)
power_df$sample_size_ratio <- as.factor(power_df$sample_size_ratio)
ggplot(power_df, aes(x = sample_size_ratio)) +
  geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
  geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
  geom_line(aes(y = power_back, group = 1, color = "power backward"), linewidth = 1.75) +  
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying sample size ratio \n Concept Drift") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 28)) + 
   theme(axis.title = element_text(size = 28)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 32), 
        legend.text = element_text(size = 32)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()


#combining them together here!
power_df <- read.csv('data_files/power_rfperm_samplesizeratio_noiseshift_bi_grid.csv')
colors <- c(
"power bidirectional" = "red",
"power forward" = "blue",
"power backward" = "orange"
  )
for(i in 1:10){
  df_cur <- power_df[(28*i-27):(28*i), ]
  png(paste("rfperm", i, "samplesize_noiseshift.png", sep = "_"), width = 900, height = 950)
  df_cur$sample_size_ratio <- as.factor(df_cur$sample_size_ratio)
  ggplot(df_cur, aes(x = sample_size_ratio)) +
    geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
    geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
    geom_line(aes(y = power_rev, group = 1, color = "power backward"), linewidth = 1.75) +  
    labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
  ggtitle(paste("Power for Permutation Test - varying sample size ratio \n Noise Shift ", i * 0.1, sep = "")) +   
  scale_color_manual(values = colors) +   
  scale_y_continuous(limits = c(0, 1)) +  
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
  panel.background = element_blank(), axis.line = element_line(colour = "black")) +
       theme(plot.title = element_text(size = 32)) + 
     theme(axis.text = element_text(size = 25)) + 
     theme(axis.title = element_text(size = 25)) + 
     theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
    theme(legend.position='bottom') + 
    theme(legend.title = element_text(size = 29), 
          legend.text = element_text(size = 29)) + 
    theme(legend.title = element_blank()) +   
    theme(legend.key.size = unit(1, 'cm')) 
  dev.off()
}

df_cur <- power_df[power_df$sample_size_ratio == 0.2, ]
png("rfperm_samplesize02_conceptdrift.png", width = 900, height = 950)
df_cur$noise_shift <- as.factor(df_cur$noise_shift)
ggplot(df_cur, aes(x = noise_shift)) +
  geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
  geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
  geom_line(aes(y = power_rev, group = 1, color = "power backward"), linewidth = 1.75) +  
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle("Power for Permutation Test - varying noise shift \n Sample-Size ratio 0.2") +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 25)) + 
   theme(axis.title = element_text(size = 25)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 29), 
        legend.text = element_text(size = 29)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()



df_cur <- power_df[power_df$sample_size_ratio == 0.2, ]
png("rfperm_samplesize02_noise_shift.png", width = 900, height = 950)
df_cur$noise_shift <- as.factor(df_cur$noise_shift)
ggplot(df_cur, aes(x = noise_shift)) +
  geom_line(aes(y = power_bi, group = 1, color = "power bidirectional"), linewidth = 1.75) + 
  geom_line(aes(y = power_for, group = 1, color = "power forward"), linewidth = 1.75) + 
  geom_line(aes(y = power_rev, group = 1, color = "power backward"), linewidth = 1.75) +  
  labs(x = "Sample-Size Ratio n_exist/n_new", y = "Power", color = "Legend") + theme_bw() + 
ggtitle(paste("Power for Permutation Test - varying noise shift \n Sample-Size ratio 0.067", str(i * 0.1), sep = "")) +   
scale_color_manual(values = colors) +   
scale_y_continuous(limits = c(0, 1)) +  
theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
panel.background = element_blank(), axis.line = element_line(colour = "black")) +
     theme(plot.title = element_text(size = 32)) + 
   theme(axis.text = element_text(size = 25)) + 
   theme(axis.title = element_text(size = 25)) + 
   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(legend.position='bottom') + 
  theme(legend.title = element_text(size = 29), 
        legend.text = element_text(size = 29)) + 
  theme(legend.title = element_blank()) +   
  theme(legend.key.size = unit(1, 'cm')) 
dev.off()










